"""체험판의 시작 코드. 브라우저 안의 파이썬(Pyodide)에서만 돈다.

서버 프로그램(app.py)을 그대로 불러와, 화면이 보내는 요청을 서버 대신 처리한다.
캠페인 기록은 브라우저 저장소(/kai_data)에 두고, AI 호출 자리는 demo_stubs가 받아 둔 답으로 바꾼다.
"""
import json
import shutil
import sys
import types
from pathlib import Path

from pyodide.ffi import to_js

ROOT, DATA = Path("/kai"), Path("/kai_data")
sys.path[:0] = [str(ROOT), str(ROOT / "lib")]

# 체험판에는 AI 연결 패키지가 없다. 코드가 이름을 찾을 수 있게 빈 껍데기만 둔다 (실제로 부르지 않는다)
_fake = types.ModuleType("anthropic")
for _name in ("AuthenticationError", "RateLimitError", "APIStatusError", "APIConnectionError"):
    setattr(_fake, _name, type(_name, (Exception,), {}))
sys.modules["anthropic"] = _fake

import app as kai_app            # noqa: E402
import demo_stubs                # noqa: E402
from src import store            # noqa: E402

store.DATA = DATA
demo_stubs.install(kai_app, json.loads((ROOT / "replay.json").read_text(encoding="utf-8")))
_client = kai_app.app.test_client()
_MARK = "seed_version.txt"


def seed(force=False):
    """처음 열었거나 예시 캠페인이 바뀌었으면 예시 캠페인을 채운다. 채웠으면 True."""
    version = (ROOT / "seed" / _MARK).read_text(encoding="utf-8")
    mark = DATA / _MARK
    if not force and mark.exists() and mark.read_text(encoding="utf-8") == version:
        return False
    for item in DATA.iterdir():
        shutil.rmtree(item) if item.is_dir() else item.unlink()
    for item in (ROOT / "seed").iterdir():
        shutil.copytree(item, DATA / item.name) if item.is_dir() else shutil.copy(item, DATA / item.name)
    return True


def handle(method, path, content_type, body):
    """화면의 요청 하나를 서버 프로그램에 넘기고 [상태, 형식, 내려받기 이름, 내용]을 돌려준다."""
    data = bytes(body.to_py()) if body is not None else None
    resp = _client.open(path, method=method, data=data, content_type=content_type or None)
    resp.direct_passthrough = False
    return to_js([resp.status_code, resp.headers.get("Content-Type") or "",
                  resp.headers.get("Content-Disposition") or "", to_js(resp.get_data())])
