"""소재 기획 도우미: 앱 소개를 읽고 소재 방안을 제안하고, 광고주가 쓴 문구를 점검한다.

AI는 초안과 의견만 쓴다. 글자 수 같은 규격은 코드가 rules.yaml로 다시 확인하고, 실제로 쓸지는 광고주가 고른다.
AI 초안에는 리워드 금액을 쓰지 않기로 했다 (rules.yaml no_reward_amount). AI에게 쓰지 말라고 하고, 썼으면 코드가 표시한다.
광고주가 직접 쓴 금액은 막지 않고 운영자 검수에 표시한다.
"""
import json
import time

import anthropic

from ..intake import REWARD_AMOUNT as _AMOUNT
from .client import MODEL, LLMUnavailable, client, cost_usd

_TEXT = {"type": "string"}
_COMMON = """지켜 주세요:
- 초안에는 리워드 금액을 쓰지 않습니다. 금액은 광고주와 운영자가 정하는 값이라 지어내면 안 됩니다. '리워드 지급'처럼 보상이 있다는 사실은 쓰되, 500원이나 100포인트 같은 숫자는 어디에도 쓰지 않습니다.
- 앱 소개에 없는 기능이나 혜택은 지어내지 않습니다. 광고주가 적은 내용만 근거로 삼습니다. \
앱 이름만 보고 어떤 앱인지 짐작하지 않습니다. 이름으로는 앱이 하는 일을 알 수 없기 때문입니다.
- 유저가 읽는 문구이므로 쉽고 짧은 한국어로 씁니다."""


def _ask(prompt, schema):
    """AI에 묻고 (답, 실행 정보)를 돌려준다. 실패하면 답 자리에 None, 실행 정보에 reason."""
    started = time.time()
    try:
        response = client().beta.messages.create(
            model=MODEL,
            max_tokens=16000,
            # 이 모델이 안전 장치 때문에 답을 거절하면 다른 모델이 같은 요청을 이어받게 한다
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            output_config={"effort": "low", "format": {"type": "json_schema", "schema": schema}},
            messages=[{"role": "user", "content": prompt}],
        )
    except LLMUnavailable as e:
        return None, {"reason": str(e)}
    except anthropic.AuthenticationError:
        return None, {"reason": "API 키가 올바르지 않거나 만료됐어요."}
    except anthropic.RateLimitError:
        return None, {"reason": "요청이 많아 잠시 후 다시 시도해야 해요."}
    except anthropic.APIStatusError as e:
        return None, {"reason": f"AI 서비스 오류 ({e.status_code}): {e.message}"}
    except anthropic.APIConnectionError:
        return None, {"reason": "AI 서비스에 연결하지 못했어요. 인터넷 연결을 확인해 주세요."}

    run = {
        "model": response.model,
        "seconds": round(time.time() - started, 1),
        "input_tokens": response.usage.input_tokens,
        "output_tokens": response.usage.output_tokens,
        "cost_usd": round(cost_usd(response.usage), 5),
    }
    if response.stop_reason != "end_turn":
        return None, {"reason": f"AI가 답을 끝내지 못했어요 ({response.stop_reason}).", **run}
    return json.loads(next(b.text for b in response.content if b.type == "text")), run


def _context(app, product, rules):
    spec = rules["rules"]["R8_creative"]["proposal"]
    action = rules["documents"]["product_labels"].get(product, product)
    patterns = "\n".join("- " + line for line in spec["proven_patterns"])
    return f"""오퍼월 유저는 리워드를 받으려고 광고 목록을 훑어봅니다. 그래서 '무엇을 하면 되는지'와 '보상이 있다는 것'이 \
한눈에 보이는 소재가 선택됩니다. 앱 자체의 매력은 그 다음입니다.

<캠페인>
앱 이름: {app}
상품: {product} ({action})
리워드 지급 조건: {rules["rules"]["R8_creative"]["payout_condition"][product]}
</캠페인>

문구에 리워드 지급 조건을 쓸 때는 위 조건 그대로 씁니다. 운영사가 정한 값이라 바꿀 수 없고, \
조건이 아닌 행동을 해야 지급된다고 쓰면 유저에게 틀린 안내가 됩니다.

<운영 경험에서 반응이 좋았던 방식>
{patterns}
</운영 경험에서 반응이 좋았던 방식>"""


def name_problems(name, product, rules, strict_prefix=True):
    """캠페인 이름을 규칙으로 확인한다. strict_prefix가 아니면 머리말은 권장 사항으로만 본다."""
    r8 = rules["rules"]["R8_creative"]
    limit, prefix, problems = r8["campaign_name"]["max_chars"], r8["proposal"]["name_prefix"][product], []
    if len(name) > limit:
        problems.append(f"{len(name)}자예요. {limit}자를 넘는 부분은 잘려요.")
    if not name.startswith(prefix):
        problems.append(f"{prefix}로 시작하지 않아요." if strict_prefix else f"이름 앞에 {prefix}를 붙이면 참여가 쉽다는 것이 바로 보여요.")
    if _AMOUNT.search(name):
        # AI 초안이면 규칙 위반이고, 광고주가 직접 쓴 것이면 써도 되지만 운영자가 확인한다
        problems.append("리워드 금액이 들어 있어요. AI 초안에는 금액을 쓰지 않아요." if strict_prefix
                        else "리워드 금액이 들어 있어요. 써도 되지만, 운영자가 검수할 때 실제 지급액과 맞는지 확인해요.")
    return problems


def _amount_problem(text):
    return ["리워드 금액이 들어 있어요. AI 초안에는 금액을 쓰지 않아요."] if _AMOUNT.search(text) else []


def _repair_names(names, product, rules, context):
    """규칙에 어긋난 캠페인 이름(글자 수 초과, 머리말 없음, 금액)은 AI에게 한 번 더 고치게 하고, 그래도 어긋나면 뺀다.
    AI가 틀릴 수 있다는 것을 알았으니, 틀린 이름을 '표시만' 하고 보여 주지 않는다 [결정]. 결과: (이름 목록, 고치기 실행 정보 또는 None)"""
    r8 = rules["rules"]["R8_creative"]
    limit, prefix = r8["campaign_name"]["max_chars"], r8["proposal"]["name_prefix"][product]
    names = [n.strip() for n in names if n.strip()]
    bad = [n for n in names if name_problems(n, product, rules)]
    if not bad:
        return names, None
    schema = {"type": "object", "additionalProperties": False, "required": ["names"],
              "properties": {"names": {"type": "array", "items": _TEXT}}}
    listed = "\n".join(f"- {n} ({len(n)}자)" for n in bad)
    prompt = f"""아래 캠페인 이름 후보가 규칙에 어긋났습니다. 뜻은 살리되 규칙에 맞게 다시 써서, 같은 순서로 하나씩 돌려주세요.
규칙: "{prefix}"로 시작하고, 머리말과 공백을 모두 포함해 {limit}자 이내입니다. 리워드 금액은 쓰지 않습니다. \
글자 수를 하나하나 세어 {limit}자 이내인지 확인한 뒤에 답합니다. 줄이기 어려우면 낱말을 빼서라도 {limit}자 안에 맞춥니다.

{context}

<고칠 이름>
{listed}
</고칠 이름>"""
    data, run = _ask(prompt, schema)
    fixed = dict(zip(bad, [x.strip() for x in data["names"]])) if data else {}
    out = []
    for n in names:
        m = fixed.get(n, n)
        if not name_problems(m, product, rules):
            out.append(m)
    return out, run


def _merge_runs(run, extra):
    """고치기 호출의 시간과 비용을 본 호출에 더한다 (AI 실행 기록은 하나로 남긴다)."""
    if not extra or "cost_usd" not in extra:
        return run
    return {**run, "seconds": round(run["seconds"] + extra["seconds"], 1), "cost_usd": round(run["cost_usd"] + extra["cost_usd"], 5), "repaired": True}


def _check(data, product, rules):
    """AI가 쓴 초안을 규칙으로 다시 확인한다. 고칠 점은 지우지 않고 표시해 광고주가 보게 한다."""
    names = [{"text": n.strip(), "chars": len(n.strip()), "problems": name_problems(n.strip(), product, rules)} for n in data["names"]]
    images = [{**m, "problems": ["이미지 안에는 리워드 금액을 넣을 수 없어요."] if _AMOUNT.search(m["headline"] + m["concept"]) else []}
              for m in data["image_directions"]]
    descs = [{"text": d.strip(), "problems": _amount_problem(d)} for d in data["descriptions"]]
    return {"names": names, "descriptions": descs, "image_directions": images}


def find_points(app, product, intro, rules):
    """앱 소개에서 소구 포인트 후보를 찾는다. 광고주가 이 가운데 고른다. 결과: status, points."""
    spec = rules["rules"]["R8_creative"]["proposal"]
    schema = {
        "type": "object", "additionalProperties": False, "required": ["points"],
        "properties": {"points": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["point", "reason"],
            "properties": {"point": _TEXT, "reason": _TEXT}}}},
    }
    prompt = f"""오퍼월(앱 안의 리워드 광고 목록)에 올릴 광고 소재를 기획하려고 합니다. 먼저 이 앱에서 유저에게 내세울 만한 \
소구 포인트 후보를 찾아 주세요. 광고주가 이 가운데 최대 {spec['max_selected_points']}개를 골라 소재의 방향을 정합니다.

{_context(app, product, rules)}

<광고주가 적은 앱 소개>
{intro}
</광고주가 적은 앱 소개>

만들 것: 소구 포인트 후보 {spec['point_candidates']}개.
- 각 후보는 12자 안팎의 짧은 이름과, 왜 오퍼월 유저에게 통하는지 한 문장의 이유로 적습니다. \
후보 이름은 완성된 문구가 아니라 방향을 가리키는 말이므로 [앱설치] 같은 머리말은 붙이지 않습니다.
- 광고주가 골라 조합할 수 있도록 후보끼리 서로 겹치지 않게 합니다. 참여가 쉽다는 점, 보상이 있다는 점, 앱 자체의 쓸모를 고루 담습니다.

{_COMMON}"""
    data, run = _ask(prompt, schema)
    if data is None:
        return {"status": "failed", **run}
    points = [{"point": p["point"].strip(), "reason": p["reason"].strip()} for p in data["points"] if p["point"].strip()]
    return {"status": "ok", "points": points, **run}


def suggest_creative(app, product, intro, points, rules):
    """광고주가 고른 소구 포인트로 소재 초안을 쓴다. 결과: status, ideas(코드가 확인한 제안), 실행 정보."""
    r8 = rules["rules"]["R8_creative"]
    spec, limit = r8["proposal"], r8["campaign_name"]["max_chars"]
    schema = {
        "type": "object", "additionalProperties": False,
        "required": ["names", "descriptions", "image_directions"],
        "properties": {
            "names": {"type": "array", "items": _TEXT},
            "descriptions": {"type": "array", "items": _TEXT},
            "image_directions": {"type": "array", "items": {
                "type": "object", "additionalProperties": False, "required": ["concept", "headline"],
                "properties": {"concept": _TEXT, "headline": _TEXT}}},
        },
    }
    chosen = "\n".join("- " + p for p in points)
    prompt = f"""오퍼월(앱 안의 리워드 광고 목록)에 올릴 광고 소재의 초안을 제안해 주세요.

{_context(app, product, rules)}

<광고주가 적은 앱 소개>
{intro}
</광고주가 적은 앱 소개>

<광고주가 고른 소구 포인트>
{chosen}
</광고주가 고른 소구 포인트>

광고주가 소재의 방향을 직접 정한 것이므로, 아래 초안은 고른 소구 포인트를 중심으로 씁니다. 고르지 않은 내용을 앞세우지 않습니다.

만들 것:
1. 캠페인 이름 후보 {spec['name_candidates']}개. 모두 "{spec['name_prefix'][product]}"로 시작하고, 공백을 포함해 {limit}자 이내입니다. \
광고 목록에서 {limit}자를 넘는 부분은 잘리기 때문입니다. 후보끼리는 표현이 서로 달라야 고를 수 있습니다.
2. 소개와 참여방법 초안 {spec['description_candidates']}개. 각각 앱을 한두 문장으로 소개한 뒤, 참여방법을 번호 목록으로 적습니다. \
유의사항은 따로 있으니 쓰지 않습니다. 광고주가 비교해서 고를 수 있도록 초안끼리는 앱을 소개하는 각도나 말투가 서로 달라야 합니다.
3. 소재 이미지(1200×600 가로 배너) 방향 {spec['image_directions']}개. 각각 어떤 장면과 구성인지, 그리고 이미지에 넣을 짧은 문구.

{_COMMON}"""
    data, run = _ask(prompt, schema)
    if data is None:
        return {"status": "failed", **run}
    data["names"], extra = _repair_names(data["names"], product, rules, _context(app, product, rules))
    return {"status": "ok", "ideas": _check(data, product, rules), **_merge_runs(run, extra)}


def review_copy(app, product, name, desc, rules):
    """광고주가 쓴 캠페인 이름과 소개를 점검한다. 결과: status, review(잘된 점, 고칠 점, 고친 예)."""
    r8 = rules["rules"]["R8_creative"]
    spec, limit = r8["proposal"], r8["campaign_name"]["max_chars"]
    schema = {
        "type": "object", "additionalProperties": False,
        "required": ["good_points", "issues", "improved_name", "improved_description"],
        "properties": {
            "good_points": {"type": "array", "items": _TEXT},
            "issues": {"type": "array", "items": {
                "type": "object", "additionalProperties": False, "required": ["target", "what", "why"],
                "properties": {"target": {"type": "string", "enum": ["name", "description"]}, "what": _TEXT, "why": _TEXT}}},
            "improved_name": _TEXT,
            "improved_description": _TEXT,
        },
    }
    prompt = f"""광고주가 오퍼월(앱 안의 리워드 광고 목록)에 올리려고 쓴 문구입니다. 제출하기 전에 점검해 주세요. \
운영자가 검수에서 돌려보내는 일을 줄이는 것이 목적입니다.

{_context(app, product, rules)}

<광고주가 쓴 캠페인 이름>
{name}
</광고주가 쓴 캠페인 이름>

<광고주가 쓴 소개와 참여방법>
{desc or "(아직 쓰지 않음)"}
</광고주가 쓴 소개와 참여방법>

만들 것:
1. 잘된 점. 있으면 1~2개, 없으면 빈 목록.
2. 고칠 점. 유저가 헷갈리거나 놓칠 만한 것만 적습니다. 각각 이름과 소개 중 어디의 문제인지, 무엇이 문제인지, 왜 문제인지. 문제가 없으면 빈 목록.
3. 고친 캠페인 이름 하나. "{spec['name_prefix'][product]}"로 시작하고 공백을 포함해 {limit}자 이내입니다. 광고 목록에서 {limit}자를 넘는 부분은 잘립니다.
4. 고친 소개와 참여방법 하나. 광고주의 글을 살려 고치고, 참여방법은 번호 목록으로 적습니다. 광고주가 아직 쓰지 않았다면 빈 글로 둡니다.

{_COMMON.replace("앱 소개에 없는", "광고주의 글에 없는")}"""
    data, run = _ask(prompt, schema)
    if data is None:
        return {"status": "failed", **run}
    better_desc = data["improved_description"].strip()
    # 고친 이름도 규칙에 맞아야 보여 준다. 고쳐도 안 맞으면 빈 글로 둔다 (고친 예 없음)
    fixed, extra = _repair_names([data["improved_name"]], product, rules, _context(app, product, rules))
    better_name = fixed[0] if fixed else ""
    return {"status": "ok", **_merge_runs(run, extra), "review": {
        "good_points": data["good_points"], "issues": data["issues"],
        "improved_name": {"text": better_name, "chars": len(better_name), "problems": name_problems(better_name, product, rules)},
        "improved_description": {"text": better_desc, "problems": _amount_problem(better_desc)},
    }}
