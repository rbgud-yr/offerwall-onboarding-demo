"""AI가 올라온 것을 보고 확인한다: 광고 소재 검수, 날인본 확인.

AI는 보고 읽는 일을 한다 (이미지 속 글자, 서류의 종류, 도장이 있는지, 소개 글에 참여방법이 있는지).
금액 표기 같은 규칙 위반은 AI가 읽어 준 글자를 코드가 다시 검사해서 판단한다.
AI가 안 될 때는 사람이 직접 확인하는 원래 흐름으로 돌아간다.
"""
import base64
import re
from pathlib import Path

from ..intake import REWARD_AMOUNT, default_cautions
from .creative_ideas import name_problems
from .creative_ideas import _ask

_TEXT = {"type": "string"}
_IMAGE_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".gif": "image/gif"}


def _file_block(path):
    """이미지나 PDF를 AI에 보낼 수 있는 형태로 바꾼다. 보낼 수 없는 형식이면 None."""
    path = Path(path)
    data = base64.standard_b64encode(path.read_bytes()).decode("utf-8")
    suffix = path.suffix.lower()
    if suffix in _IMAGE_TYPES:
        return {"type": "image", "source": {"type": "base64", "media_type": _IMAGE_TYPES[suffix], "data": data}}
    if suffix == ".pdf":
        return {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": data}}
    return None


def review_creative(image_path, app, product, creative, rules):
    """광고 소재를 검수한다. 결과: status(ok / failed), review(passed, issues, opinions, tips, image_texts), 실행 정보.

    issues는 승인을 막는 것(금지 내용, 리워드 금액), opinions는 알려만 주는 의견이다.
    """
    r8 = rules["rules"]["R8_creative"]
    spec, action = r8["review"], rules["documents"]["product_labels"].get(product, product)
    block = _file_block(image_path)
    if not block:
        return {"status": "failed", "reason": "이 형식의 이미지는 AI가 볼 수 없어요."}
    target = {"type": "string", "enum": ["image", "name", "description", "caution"]}
    note = {"type": "object", "additionalProperties": False, "required": ["target", "what", "why"],
            "properties": {"target": target, "what": _TEXT, "why": _TEXT}}
    # 의견에는 '이런 식으로 써 보면 어떨까요'의 예시 문구를 함께 받는다 (없으면 빈 글)
    opinion = {"type": "object", "additionalProperties": False, "required": ["kind", "target", "what", "why", "example"],
               "properties": {"kind": {"type": "string", "enum": ["typo", "suggestion"]}, "target": target, "what": _TEXT, "why": _TEXT, "example": _TEXT}}
    schema = {
        "type": "object", "additionalProperties": False, "required": ["image_texts", "prohibited", "opinions"],
        "properties": {"image_texts": {"type": "array", "items": _TEXT},
                       "prohibited": {"type": "array", "items": note}, "opinions": {"type": "array", "items": opinion}},
    }
    banned = "\n".join("   - " + line for line in spec["prohibited_content"])
    prompt = f"""오퍼월(앱 안의 리워드 광고 목록)에 올릴 광고 소재를 제출 전에 봐 주세요. 광고주가 결과를 읽고 스스로 판단해 제출합니다. \
그래서 고치라고 요구하는 검사가 아니라, 광고주가 놓쳤을 만한 것을 알려 주는 일입니다. 소재에 들어가면 안 되는 내용만 따로 가려냅니다.

<캠페인>
앱 이름: {app}
상품: {product} ({action})
리워드 지급 조건: {r8['payout_condition'][product]}
</캠페인>

<캠페인 이름>
{creative['cname']}
</캠페인 이름>

<소개와 참여방법>
{creative['cdesc']}
</소개와 참여방법>

<유의사항>
{creative['ccaution']}
</유의사항>

<운영사의 표준 유의사항>
{default_cautions(product, rules)}
</운영사의 표준 유의사항>

첨부한 이미지는 광고 목록에 보이는 소재 이미지입니다.

할 일:
1. image_texts: 이미지 안에 보이는 글자를 빠짐없이, 보이는 그대로 옮겨 적습니다. 숫자와 단위를 특히 정확히 옮깁니다. \
이 글자로 리워드 금액이 들어 있는지를 따로 검사하기 때문입니다. 글자가 없으면 빈 목록입니다.
2. prohibited: 소재에 들어가면 안 되는 내용이 이름, 소개, 유의사항, 이미지에 있으면 적습니다. 해당하는 것은 아래뿐입니다. 없으면 빈 목록입니다.
{banned}
   앱의 종류만으로 판단하지 않고, 소재에 실제로 그런 내용이 드러나 있을 때만 적습니다. 확실하지 않으면 적지 않습니다.
3. opinions: 유저가 실제로 헷갈리거나 참여를 망설일 만한 문제가 있을 때만 적습니다. 문제가 없으면 빈 목록이 정상입니다. \
의견을 채우려고 억지로 찾지 않습니다. 많아야 {spec['max_opinions']}개이고, 중요한 것부터 적습니다. 볼 것은 아래뿐입니다.
   - 명백한 오타나 맞춤법 오류
   - 이미지의 글자가 너무 작거나 배경과 겹쳐 읽기 어려움
   - 이미지가 이 앱이 아니라 다른 앱이나 서비스의 것으로 보임
   - 소개에 어떤 앱인지가 잘 드러나지 않거나 너무 짧음
   - 무엇을 하면 리워드를 받는지(참여방법)가 없거나 한눈에 안 들어옴
   - 캠페인 이름, 소개, 이미지가 서로 다른 내용을 말함

의견으로도 적지 않는 것:
- 상품과 참여방법의 차이. 설치만 하면 지급되는 상품이라도 광고주는 소개에서 회원가입이나 그 뒤의 행동을 안내할 수 있습니다. \
가입까지 유도하려고 이 상품을 집행하는 광고주가 있기 때문입니다. 이것은 광고주의 선택이므로 짚지 않습니다.
- 운영사의 표준 유의사항. 광고주가 쓴 것이 아니라 모든 캠페인에 넣는 문구입니다. 이 문구 자체나 이 문구와 소개·이미지 사이의 차이는 짚지 않습니다.
- 글자 수와 리워드 금액 표기. 코드가 따로 검사합니다.
- 뜻이 같은 다른 표현으로 바꾸자는 것. 예: '실행이 확인되면 리워드가 지급됩니다'는 지급 조건과 뜻이 같으므로 고칠 것이 없습니다.
- 캠페인 이름 앞의 머리말(예: [앱설치], [앱실행], [회원가입]). 운영사 규칙이므로 빼거나 바꾸지 않습니다. 이름 예시를 쓸 때도 그대로 둡니다.
- 이미 소재에 들어 있는 내용을 다시 넣자는 것.

의견을 쓰는 법:
- 오타는 kind를 "typo"로 하고, what을 "'틀린 글자' → '바른 글자'" 형태로만 씁니다. why와 example은 빈 글로 둡니다.
- 그 밖의 의견은 kind를 "suggestion"으로 하고, what은 무엇을 해 보자는 것인지 15자 안팎의 짧은 제목으로 씁니다 \
(예: "이미지에 앱 이름 넣기", "참여방법을 단계로 나누기"). 화면이 "이런 식으로 작성해 보면 어떨까요?"라는 말을 위에 한 번 보여 주므로, \
의견마다 그 말을 되풀이하지 않습니다. 같은 대상에 대한 비슷한 의견은 하나로 합칩니다. \
example에는 바로 가져다 쓸 수 있는 예시 문구를 적습니다. \
예시는 광고주가 쓴 내용만 근거로 삼고, 없는 기능이나 혜택, 리워드 금액은 지어내지 않습니다. \
앱 이름만 보고 어떤 앱인지 짐작하지 않습니다. 이름으로는 앱이 하는 일을 알 수 없기 때문입니다 (예: '블루버튼'이 무슨 앱인지 이름으로는 알 수 없습니다). \
광고주가 어떤 앱인지 쓰지 않았다면 예시에서 그 자리를 "(어떤 앱인지 한 문장)"처럼 광고주가 채울 빈칸으로 남깁니다. \
예시에 리워드 지급 조건을 쓸 때는 위 <캠페인>의 지급 조건 그대로 씁니다. 조건이 아닌 행동(실행, 가입, 결제 등)을 해야 지급된다고 쓰면 \
유저에게 틀린 안내가 됩니다. 지급 조건과 상관없이 가입 같은 다음 행동을 권하는 문장은 써도 됩니다. \
캠페인 이름의 예시는 공백을 포함해 {r8['campaign_name']['max_chars']}자 이내로 씁니다. 예시를 들 것이 없으면 example은 빈 글로 둡니다. \
광고주가 이미 그렇게 써 두었다면 그 의견은 내지 않습니다. 예시가 지금 문구와 같아지는 의견은 의견이 아닙니다.
- why에는 지금 문구 때문에 유저가 무엇을 헷갈리거나 놓치는지, 구체적인 문제를 짧은 한 문장으로 적습니다. 문제를 한 문장으로 말할 수 없으면 그 의견은 내지 않습니다.
- 고치라고 요구하는 말("~해야 합니다", "~하세요")은 쓰지 않습니다."""
    data, run = _ask([block, {"type": "text", "text": prompt}], schema)
    if data is None:
        return {"status": "failed", **run}
    return {"status": "ok", "review": judge(data, creative, product, rules), **run}


def judge(data, creative, product, rules):
    """AI가 본 것에 규칙 검사를 더해 검수 결과를 만든다. 금지 내용과 리워드 금액만 승인을 막고, 나머지는 의견으로 알려만 준다."""
    r8 = rules["rules"]["R8_creative"]
    why = r8["review"]["reward_amount_reason"]
    texts = [t.strip() for t in data["image_texts"] if t.strip()]
    issues = [{**i, "by": "AI", "level": "금지 내용"} for i in data["prohibited"]]
    for text in texts:
        found = REWARD_AMOUNT.search(text)
        if found:
            issues.append({"target": "image", "by": "규칙", "level": "리워드 금액", "what": f"이미지에 리워드 금액이 있어요: \"{found.group(0)}\"", "why": why})
    for key, target, label in (("cname", "name", "캠페인 이름"), ("cdesc", "description", "소개 · 참여방법")):
        found = REWARD_AMOUNT.search(creative.get(key) or "")
        if found:
            issues.append({"target": target, "by": "규칙", "level": "리워드 금액", "what": f"{label}에 리워드 금액이 있어요: \"{found.group(0)}\"", "why": why})
    prefix = r8["proposal"]["name_prefix"][product]
    tips = [] if creative["cname"].startswith(prefix) else [f"캠페인 이름 앞에 {prefix}를 붙이면 참여가 쉽다는 것이 바로 보여요."]
    # AI가 예시 문구에서 지급 조건을 다르게 쓰면 그 예시는 빼고 의견만 남긴다 (틀린 안내를 광고주가 가져다 쓰지 않게)
    wrong = re.compile("(" + "|".join(r8["payout_wrong_actions"][product]) + r")[^.\n]{0,12}(지급|받을 수|받아요|드려|드립니다)")
    opinions = [{**o, "by": "AI", "example": "" if wrong.search(o.get("example") or "") else (o.get("example") or "")} for o in data["opinions"]]
    # AI가 이미 적용된 문구를 그대로 '제안'으로 돌려주면 고칠 것이 없는 의견이므로 뺀다 (띄어쓰기·줄바꿈 차이는 무시)
    flat = lambda s: re.sub(r"\s+", "", s or "")
    field = {"name": "cname", "description": "cdesc", "caution": "ccaution"}
    opinions = [o for o in opinions if not (o["example"] and o.get("target") in field
                                            and flat(o["example"]) == flat(creative.get(field[o["target"]])))]
    # 캠페인 이름 예시가 머리말을 빼거나 20자를 넘기는 등 규칙에 어긋나면 그 의견은 뺀다 (광고주가 틀린 이름을 가져다 쓰지 않게)
    opinions = [o for o in opinions if not (o.get("kind") != "typo" and o.get("target") == "name" and o["example"]
                                            and name_problems(o["example"], product, rules))]
    # 많아야 정해진 개수만. 오타를 먼저 보여 준다
    opinions = sorted(opinions, key=lambda o: o.get("kind") != "typo")[:r8["review"].get("max_opinions", 3)]
    return {"passed": not issues, "issues": issues, "opinions": opinions, "tips": tips, "image_texts": texts}


def check_seal(file_path, company):
    """올린 날인본이 광고게재신청서가 맞는지, 날인이 있는지 본다. 결과: status, check(is_application, has_seal, company_seen, note)."""
    block = _file_block(file_path)
    if not block:
        return {"status": "failed", "reason": "이 형식의 파일은 AI가 볼 수 없어요."}
    schema = {
        "type": "object", "additionalProperties": False, "required": ["is_application", "has_seal", "company_seen", "note"],
        "properties": {"is_application": {"type": "boolean"}, "has_seal": {"type": "boolean"},
                       "company_seen": {"type": ["string", "null"]}, "note": _TEXT},
    }
    prompt = f"""광고주가 '날인한 광고게재신청서'라며 올린 파일입니다. 한 번 내면 바꿀 수 없는 서류라, 잘못 올린 것을 그 자리에서 알려 주려고 합니다.

확인할 것:
1. is_application: 광고게재신청서(광고 게재를 신청하는 계약 서류)로 보이는가. 전혀 다른 서류나 사진이면 false입니다.
2. has_seal: 도장(인감)이나 서명이 찍혀 있는가. 도장 자리만 있고 비어 있으면 false입니다.
3. company_seen: 서류에 적힌 신청 회사 이름. 읽을 수 없으면 null입니다. (참고: 신청 회사는 "{company}"여야 합니다)
4. note: 광고주에게 알려 줄 것이 있으면 한 문장으로. 없으면 빈 글입니다.

확실하지 않으면 통과시키는 쪽으로 판단합니다. 멀쩡한 서류를 막는 것이 더 큰 불편이기 때문입니다."""
    data, run = _ask([block, {"type": "text", "text": prompt}], schema)
    if data is None:
        return {"status": "failed", **run}
    return {"status": "ok", "check": {"is_application": bool(data["is_application"]), "has_seal": bool(data["has_seal"]),
                                      "company_seen": (data["company_seen"] or "").strip() or None, "note": data["note"].strip()}, **run}


def check_final_seal(file_path, company, operator):
    """운영사가 광고주에게 보내려는 최종본에 광고주와 운영사의 날인이 모두 있는지 본다.
    결과: status, check(is_application, advertiser_seal, operator_seal, note). 올리는 즉시 광고주에게 전달되므로 먼저 본다."""
    block = _file_block(file_path)
    if not block:
        return {"status": "failed", "reason": "이 형식의 파일은 AI가 볼 수 없어요."}
    schema = {
        "type": "object", "additionalProperties": False, "required": ["is_application", "advertiser_seal", "operator_seal", "note"],
        "properties": {"is_application": {"type": "boolean"}, "advertiser_seal": {"type": "boolean"},
                       "operator_seal": {"type": "boolean"}, "note": _TEXT},
    }
    prompt = f"""운영사가 광고주에게 보내려는 '양사 날인이 끝난 최종 광고게재신청서'입니다. 올리는 즉시 광고주에게 전달되므로, 날인이 빠진 파일을 보내지 않도록 먼저 확인합니다.

신청 회사(광고주): "{company}"
운영사: "{operator}"

확인할 것:
1. is_application: 광고게재신청서(광고 게재를 신청하는 계약 서류)로 보이는가. 전혀 다른 서류나 사진이면 false입니다.
2. advertiser_seal: 신청 회사(광고주) 쪽 날인란에 도장이나 서명이 있는가.
3. operator_seal: 운영사 쪽 날인란에 도장이나 서명이 있는가. 운영사 날인란이 비어 있거나 도장이 하나뿐이면 false입니다.
4. note: 보내기 전에 운영자가 직접 확인해야 할 점이 있을 때만 한 문장으로. 문제가 없으면 반드시 빈 글입니다. \
note가 있으면 파일을 보내지 않고 운영자에게 먼저 보여 줍니다.

광고주 날인만 있는 파일을 최종본으로 잘못 올리는 경우를 막는 것이 목적입니다. 운영사 날인이 분명히 보이지 않으면 operator_seal은 false입니다."""
    data, run = _ask([block, {"type": "text", "text": prompt}], schema)
    if data is None:
        return {"status": "failed", **run}
    return {"status": "ok", "check": {"is_application": bool(data["is_application"]), "advertiser_seal": bool(data["advertiser_seal"]),
                                      "operator_seal": bool(data["operator_seal"]), "note": data["note"].strip()}, **run}
