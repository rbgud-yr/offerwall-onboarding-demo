"""사업자등록증 이미지에서 계약에 필요한 값을 읽는다.

AI는 읽기만 한다. 읽은 값은 사람이 확인한 뒤에만 저장하고, 사업자번호는 코드가 다시 검증한다.
"""
import base64
import json
import time
from pathlib import Path

import anthropic

from ..validate import check_biz_no
from .client import MODEL, LLMUnavailable, client, cost_usd

FIELDS = {
    "name": "상호 (법인명 또는 단체명)",
    "ceo": "대표자 이름",
    "biz_no": "사업자등록번호",
    "address": "사업장 소재지",
    "biz_type": "업태",
    "biz_item": "종목",
}
_MEDIA_TYPES = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                ".webp": "image/webp", ".gif": "image/gif", ".pdf": "application/pdf"}   # 광고주는 PDF로 주는 경우가 많다

_SCHEMA = {
    "type": "object",
    "properties": {
        "is_business_registration": {
            "type": "boolean",
            "description": "이미지가 한국의 사업자등록증이면 true",
        },
        **{key: {"type": ["string", "null"], "description": label} for key, label in FIELDS.items()},
    },
    "required": ["is_business_registration", *FIELDS],
    "additionalProperties": False,
}

_PROMPT = """이 이미지는 광고주가 계약을 위해 올린 서류입니다. 한국의 사업자등록증인지 확인하고, \
맞다면 아래 값을 서류에 적힌 그대로 옮겨 주세요.

읽은 값은 광고게재신청서와 세금계산서에 그대로 들어가므로, 추측해서 채우면 잘못된 계약서가 만들어집니다. \
그래서 글자가 가려졌거나 흐려서 확실하지 않은 항목은 null로 두세요. 사람이 그 칸만 직접 입력합니다.

- 띄어쓰기, 괄호, (주) 같은 표기는 서류에 적힌 대로 둡니다.
- 사업자등록번호는 000-00-00000 형태로 적습니다.
- 주소는 본점 소재지가 아니라 사업장 소재지를 적습니다.
- 사업자등록증이 아니면 is_business_registration을 false로 하고 나머지는 모두 null로 둡니다."""


def read_biz_cert(image_path):
    """결과: status(ok / partial / not_cert / failed), fields, 그리고 걸린 시간·비용 등 실행 정보."""
    path = Path(image_path)
    media_type = _MEDIA_TYPES.get(path.suffix.lower())
    if not media_type:
        return {"status": "failed", "reason": "PDF, PNG, JPG 파일만 읽을 수 있어요.", "fields": {}}

    started = time.time()
    try:
        response = client().beta.messages.create(
            model=MODEL,
            max_tokens=16000,
            # 이 모델이 안전 장치 때문에 답을 거절하면 다른 모델이 같은 요청을 이어받게 한다
            betas=["server-side-fallback-2026-07-01"],
            fallbacks="default",
            output_config={"effort": "low", "format": {"type": "json_schema", "schema": _SCHEMA}},
            messages=[{"role": "user", "content": [
                {"type": "document" if media_type == "application/pdf" else "image", "source": {
                    "type": "base64", "media_type": media_type,
                    "data": base64.standard_b64encode(path.read_bytes()).decode("utf-8"),
                }},
                {"type": "text", "text": _PROMPT},
            ]}],
        )
    except LLMUnavailable as e:
        return {"status": "failed", "reason": str(e), "fields": {}}
    except anthropic.AuthenticationError:
        return {"status": "failed", "reason": "API 키가 올바르지 않거나 만료됐어요.", "fields": {}}
    except anthropic.RateLimitError:
        return {"status": "failed", "reason": "요청이 많아 잠시 후 다시 시도해야 해요.", "fields": {}}
    except anthropic.APIStatusError as e:
        return {"status": "failed", "reason": f"AI 서비스 오류 ({e.status_code}): {e.message}", "fields": {}}
    except anthropic.APIConnectionError:
        return {"status": "failed", "reason": "AI 서비스에 연결하지 못했어요. 인터넷 연결을 확인해 주세요.", "fields": {}}

    run = {
        "model": response.model,
        "seconds": round(time.time() - started, 1),
        "input_tokens": response.usage.input_tokens,
        "output_tokens": response.usage.output_tokens,
        "cost_usd": round(cost_usd(response.usage), 5),
    }
    if response.stop_reason != "end_turn":
        return {"status": "failed", "reason": f"AI가 답을 끝내지 못했어요 ({response.stop_reason}).",
                "fields": {}, **run}

    data = json.loads(next(b.text for b in response.content if b.type == "text"))
    if not data.pop("is_business_registration"):
        return {"status": "not_cert", "reason": "사업자등록증이 아닌 것 같아요.", "fields": {}, **run}

    fields = {key: (data.get(key) or "").strip() or None for key in FIELDS}
    warnings = []
    if fields["biz_no"]:
        checked = check_biz_no(fields["biz_no"])
        if checked["ok"]:
            fields["biz_no"] = checked["formatted"]
        else:
            # AI가 한 자리를 잘못 읽었을 수 있다. 값은 보여주되 사람이 꼭 확인하게 한다
            warnings.append({"field": "biz_no", **checked["message"]})
    missing = [key for key, value in fields.items() if not value]
    return {"status": "partial" if missing or warnings else "ok",
            "fields": fields, "missing": missing, "warnings": warnings, **run}
