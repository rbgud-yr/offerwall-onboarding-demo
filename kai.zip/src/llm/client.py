"""Claude API 연결. AI를 부르는 코드는 모두 이 파일의 client()와 MODEL을 쓴다.

키는 .env 파일의 OFFERWALL_LLM_API_KEY에서 읽는다. Claude Code가 쓰는 ANTHROPIC_API_KEY와
이름을 다르게 둔 것은 의도한 것이다 (같은 이름이면 Claude Code가 구독 대신 API로 과금될 수 있다).
"""
import json
import threading
from datetime import date
from pathlib import Path

import anthropic

from ..rules_loader import load_rules

ENV_PATH = Path(__file__).resolve().parent.parent.parent / ".env"
# 오늘 AI를 몇 번 불렀는지. 하루 한도(rules.yaml llm.daily_limit)를 넘으면 AI 없이 직접 입력으로 넘어간다
USAGE_PATH = Path(__file__).resolve().parent.parent.parent / "data" / "ai_usage.json"
_usage_lock = threading.Lock()
MODEL = "claude-opus-5-5"
# 100만 토큰당 달러 (입력, 출력). 비용 표시용이며 모델을 바꾸면 함께 고친다
PRICE_PER_MTOK = (4.00, 20.00)


class LLMUnavailable(Exception):
    """AI를 쓸 수 없는 상태 (키 없음, 연결 실패 등). 화면은 직접 입력으로 넘어간다."""


def _read_key():
    name = load_rules()["llm"]["api_key_env"]
    if ENV_PATH.exists():
        for line in ENV_PATH.read_text(encoding="utf-8-sig").splitlines():
            if line.strip().startswith(name + "="):
                value = line.split("=", 1)[1].strip()
                if value:
                    return value
    raise LLMUnavailable(f".env 파일에 {name} 값이 없어요.")


def _count_call():
    """하루 한도를 넘으면 LLMUnavailable. 링크를 다른 사람에게 열었을 때 비용이 끝없이 나가지 않게 한다."""
    limit = load_rules()["llm"].get("daily_limit")
    if not limit:
        return
    today = date.today().isoformat()
    with _usage_lock:
        used = json.loads(USAGE_PATH.read_text(encoding="utf-8")) if USAGE_PATH.exists() else {}
        count = used.get(today, 0)
        if count >= limit:
            raise LLMUnavailable(f"오늘 쓸 수 있는 AI 횟수({limit}번)를 다 썼어요. 직접 입력해 주세요.")
        USAGE_PATH.parent.mkdir(parents=True, exist_ok=True)
        USAGE_PATH.write_text(json.dumps({today: count + 1}), encoding="utf-8")


def client():
    key = _read_key()
    _count_call()
    return anthropic.Anthropic(api_key=key)


def cost_usd(usage):
    return (usage.input_tokens * PRICE_PER_MTOK[0] + usage.output_tokens * PRICE_PER_MTOK[1]) / 1_000_000
