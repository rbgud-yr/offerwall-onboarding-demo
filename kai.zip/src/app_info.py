"""스토어의 앱 페이지를 읽어 앱 소개 글의 재료를 가져온다.

스토어 주소만 읽는다. MMP 링크나 랜딩 URL은 여는 것만으로 클릭 1건이 기록될 수 있어 읽지 않는다.

AI를 쓰지 않는다. 페이지의 제목과 설명만 뽑아 광고주에게 보여주고, 광고주가 확인하고 고친 글만 AI에 보낸다.
가져오지 못하면 광고주가 직접 적으면 되므로 실패해도 흐름은 멈추지 않는다.
"""
import html as html_lib
import ipaddress
import json
import re
import socket
import urllib.error
import urllib.request
from urllib.parse import urlparse

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
    "Accept-Language": "ko-KR,ko;q=0.9",
}


class Blocked(Exception):
    """읽으면 안 되는 주소 (스토어가 아니거나 https가 아님)."""


def _guard(url, hosts):
    """정해 둔 스토어의 https 주소만 읽는다. 이 컴퓨터나 내부망 주소로 가는 요청도 막는다."""
    parts = urlparse(url)
    if parts.scheme != "https" or not parts.hostname:
        raise Blocked("https 주소만 읽을 수 있어요.")
    if parts.hostname.lower() not in hosts:
        raise Blocked("구글 플레이나 앱스토어의 앱 페이지 주소만 읽을 수 있어요.")
    try:
        found = socket.getaddrinfo(parts.hostname, 443)
    except OSError:
        raise Blocked("주소를 찾지 못했어요.")
    for item in found:
        if not ipaddress.ip_address(item[4][0]).is_global:
            raise Blocked("읽을 수 없는 주소예요.")


def _redirects(hosts):
    class Redirects(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, req, fp, code, msg, headers, newurl):
            _guard(newurl, hosts)      # 넘어간 주소도 같은 기준으로 확인한다
            return super().redirect_request(req, fp, code, msg, headers, newurl)
    return Redirects


def _clean(fragment):
    """HTML 조각을 줄바꿈이 살아 있는 글로 바꾼다."""
    text = re.sub(r"<br\s*/?>", "\n", fragment)
    text = html_lib.unescape(re.sub(r"<[^>]+>", "", text))
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def _extract(html):
    """페이지에서 앱 이름과 설명을 뽑는다. 스토어 페이지는 설명이 있는 자리가 서로 달라 차례로 찾아본다."""
    title, candidates = "", []
    # 1) 페이지가 스스로 밝힌 앱 정보 (앱스토어는 여기에 전체 설명이 있다)
    for block in re.findall(r'<script[^>]*application/ld\+json[^>]*>(.*?)</script>', html, re.S):
        try:
            data = json.loads(block)
        except ValueError:
            continue
        for item in data if isinstance(data, list) else [data]:
            if isinstance(item, dict) and item.get("@type") in ("SoftwareApplication", "MobileApplication"):
                title = title or str(item.get("name") or "")
                candidates.append(str(item.get("description") or ""))
    # 2) 구글 플레이의 설명 칸
    for block in re.findall(r'data-g-id="description"[^>]*>(.*?)</div>', html, re.S):
        candidates.append(_clean(block))
    # 3) 일반 웹 페이지의 요약
    for tag in re.findall(r"<meta\b[^>]*>", html):
        key = re.search(r'(?:property|name)="(og:title|og:description|description)"', tag)
        content = re.search(r'content="([^"]*)"', tag)
        if key and content:
            value = html_lib.unescape(content.group(1)).strip()
            if key.group(1) == "og:title":
                title = title or value
            else:
                candidates.append(value)
    if not title:
        found = re.search(r"<title[^>]*>(.*?)</title>", html, re.S)
        title = _clean(found.group(1)) if found else ""
    return title, max(candidates, key=len, default="").strip()


def source_urls(case):
    """읽어 볼 스토어 주소 후보. CPI는 광고주가 낸 식별자로 만든다.

    CPE는 식별자를 받지 않아 후보가 없다. 광고주가 스토어 주소를 직접 넣는다 (낸 링크는 읽지 않는다).
    """
    test, urls = case.get("test") or {}, []
    if case["terms"].get("product") == "CPI":
        if test.get("aos"):
            urls.append(f"https://play.google.com/store/apps/details?id={test['aos']}&hl=ko&gl=KR")
        if test.get("ios"):
            urls.append(f"https://apps.apple.com/kr/app/id{test['ios'].lower().lstrip('id')}")
    return urls


def fetch_app_info(url, spec):
    """결과: ok, title, description, url. 실패하면 ok=False와 reason."""
    try:
        _guard(url, spec["allowed_hosts"])
        opener = urllib.request.build_opener(_redirects(spec["allowed_hosts"]))
        with opener.open(urllib.request.Request(url, headers=_HEADERS), timeout=spec["timeout_seconds"]) as res:
            final = res.geturl()
            html = res.read(spec["max_kb"] * 1024).decode(res.headers.get_content_charset() or "utf-8", errors="ignore")
    except Blocked as e:
        return {"ok": False, "reason": str(e), "url": url}
    except (urllib.error.URLError, OSError, ValueError):
        return {"ok": False, "reason": "페이지를 열지 못했어요.", "url": url}

    title, desc = _extract(html)
    if not desc:
        return {"ok": False, "reason": "페이지에서 앱 설명을 찾지 못했어요.", "url": final}
    return {"ok": True, "title": title, "description": desc, "url": final}


def intro_from(case, rules):
    """후보 주소를 차례로 읽어 처음 성공한 것으로 앱 소개 글의 재료를 만든다."""
    spec, tried = rules["rules"]["R8_creative"]["proposal"]["app_info"], []
    for url in source_urls(case):
        info = fetch_app_info(url, spec)
        tried.append({"url": url, "ok": info["ok"], "reason": info.get("reason")})
        if info["ok"]:
            text = (info["title"] + "\n" + info["description"]).strip()[: spec["max_intro_chars"]]
            return {"ok": True, "intro": text, "url": info["url"], "tried": tried}
    return {"ok": False, "tried": tried}
