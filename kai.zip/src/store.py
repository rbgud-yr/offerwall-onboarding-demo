"""캠페인별 기록 저장. 한 캠페인이 JSON 파일 하나다 (docs/데이터_모델.md).

올린 파일은 data/uploads/{캠페인 번호}/, 만든 문서는 data/docs/{캠페인 번호}/ 에 둔다.
"""
import json
import re
from datetime import datetime
from pathlib import Path

DATA = Path(__file__).resolve().parent.parent / "data"
_ID = re.compile(r"^C-\d{8}-\d{3}$")


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _case_path(case_id):
    # 캠페인 번호가 그대로 파일 경로가 되므로 형식을 먼저 확인한다
    if not _ID.match(case_id or ""):
        raise KeyError(case_id)
    return DATA / "cases" / f"{case_id}.json"


def folder(kind, case_id):
    """kind: uploads | docs"""
    _case_path(case_id)
    path = DATA / kind / case_id
    path.mkdir(parents=True, exist_ok=True)
    return path


def new_case(terms):
    (DATA / "cases").mkdir(parents=True, exist_ok=True)
    day = datetime.now().strftime("%Y%m%d")
    used = [int(p.stem[-3:]) for p in (DATA / "cases").glob(f"C-{day}-*.json")]
    case = {
        "id": f"C-{day}-{max(used, default=0) + 1:03d}",
        "created_at": now(),
        "terms": terms,
        "confirmed": False,      # 광고주가 협의 내용을 확정하면 True
        "log": [],               # 협의 내용 확정·변경 이력
        "contract": None,
        "test": None,            # 연동·테스트 정보
        "creative": None,        # 소재·캠페인 정보
        "seal_adv": None,        # 광고주가 올린 신청서 날인본
        "seal_ops": None,        # 운영사까지 날인한 최종본
        "checks": {},            # 운영자가 체크한 항목과 시각
        "setup": None,           # 운영자가 정한 운영 기간, 데일리캡, 운영 메모
        "idea_points": None,     # AI가 앱 소개에서 찾은 소구 포인트 후보 (광고주가 이 가운데 고른다)
        "ideas": None,           # AI가 마지막으로 제안한 소재 초안 (참고용)
        "review": None,          # AI가 마지막으로 점검한 광고주의 문구와 의견 (참고용)
        "creative_review": None, # AI가 한 소재 검수 결과 (통과 여부, 확인할 점, 이미지에서 읽은 글자)
        "requests": [],          # 광고주의 수정 요청 (못 바꾸는 항목을 글로 요청)
        "unlocked": {},          # 운영자가 다시 낼 수 있게 열어 준 항목
        "ops_seen": {},
        "adv_seen": {},          # 광고주가 운영사에서 온 것(최종 날인본)을 어디까지 봤는지          # 운영자가 광고주의 제출을 어디까지 봤는지 (새로 제출됨 표시용)
        "files": [],
        "ai_runs": [],
        "docs": [],
    }
    save(case)
    return case


def load(case_id):
    path = _case_path(case_id)
    if not path.exists():
        raise KeyError(case_id)
    return _upgrade(json.loads(path.read_text(encoding="utf-8")))


def _upgrade(case):
    """예전에 저장한 캠페인에 나중에 생긴 항목이 없으면 빈 값으로 채운다."""
    for key, empty in (("log", []), ("test", None), ("creative", None), ("seal_adv", None),
                       ("seal_ops", None), ("checks", {}), ("setup", None), ("idea_points", None), ("ideas", None), ("review", None), ("ops_seen", {}), ("adv_seen", {}), ("requests", []), ("unlocked", {}), ("creative_review", None), ("creative_draft_review", None), ("creative_reject", None)):
        case.setdefault(key, empty)
    return case


def save(case):
    case["updated_at"] = now()
    path = _case_path(case["id"])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(case, ensure_ascii=False, indent=2), encoding="utf-8")


def list_cases():
    folder_ = DATA / "cases"
    if not folder_.exists():
        return []
    cases = [_upgrade(json.loads(p.read_text(encoding="utf-8"))) for p in folder_.glob("C-*.json")]
    return sorted(cases, key=lambda c: c["id"], reverse=True)


def next_id(items, prefix):
    return f"{prefix}{len(items) + 1}"
