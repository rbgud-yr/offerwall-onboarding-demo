"""rules.yaml 읽기. 규칙과 수치는 이 파일로만 들어온다."""
from pathlib import Path

import yaml

RULES_PATH = Path(__file__).resolve().parent.parent / "rules.yaml"


def load_rules(path=RULES_PATH):
    with open(path, encoding="utf-8") as f:
        return yaml.safe_load(f)
