"""금액 계산과 최소 집행 검증. 계산은 전부 여기서 하고 LLM에 맡기지 않는다.

결과의 status
- ok       : 계산 완료
- ask      : 정보가 부족해 광고주에게 물어봐야 함
- escalate : 자동 처리 범위 밖이라 담당자에게 이관
"""
import math

from .rules_loader import load_rules


def _message(what, why, how):
    # 오류 안내는 무엇이 / 왜 / 어떻게 고치는지 세 가지를 함께 준다
    return {"what": what, "why": why, "how": how}


def check_biz_no(text):
    """사업자등록번호 10자리가 검증 규칙에 맞는지 확인한다. AI가 읽은 번호도 이걸로 다시 확인한다.

    마지막 자리는 앞 9자리로 계산되는 확인 숫자다. 한 자리만 잘못 읽어도 대부분 걸러진다.
    """
    digits = [int(ch) for ch in str(text or "") if ch.isdigit()]
    if len(digits) != 10:
        return {"ok": False, "message": _message(
            "사업자등록번호가 10자리가 아니에요.",
            "사업자등록번호는 숫자 10자리예요.",
            "000-00-00000 형태로 다시 확인해 주세요.",
        )}
    total = sum(d * w for d, w in zip(digits, (1, 3, 7, 1, 3, 7, 1, 3, 5))) + digits[8] * 5 // 10
    if (10 - total % 10) % 10 != digits[9]:
        return {"ok": False, "message": _message(
            "사업자등록번호가 올바르지 않아요.",
            "번호 안의 확인 숫자가 맞지 않아요. 한 자리가 잘못 입력됐을 수 있어요.",
            "사업자등록증의 등록번호와 한 자리씩 비교해 주세요.",
        )}
    d = "".join(map(str, digits))
    return {"ok": True, "formatted": f"{d[:3]}-{d[3:5]}-{d[5:]}"}


def calc_amount(product, budget=None, count=None, requester="advertiser",
                fee_requested=None, rules=None):
    """예산(원, VAT 별도) 또는 건수로 물량·수수료·입금액을 계산한다.

    requester: "advertiser" | "agency"
    fee_requested: 대행사일 때 True / False / None(언급 없음)
    """
    rules = rules or load_rules()
    result = {"status": "ok", "product": product, "messages": []}

    if product not in rules["rules"]["R3_product"]["supported"]:
        result["status"] = "escalate"
        result["messages"].append(_message(
            f"{product} 상품은 자동으로 처리하지 않아요.",
            "CPI·CPE·CPA(회원가입) 외 상품은 단가와 조건을 협의로 정해요.",
            "담당자가 확인한 뒤 회신드려요.",
        ))
        return result

    p = rules["products"][product]
    unit_price, min_count = p["unit_price"], p["min_count"]

    if budget is None and count is None:
        result["status"] = "ask"
        result["messages"].append(_message(
            "예산이나 집행 건수가 없어요.",
            "물량과 입금액을 계산하려면 둘 중 하나가 필요해요.",
            f"예산(VAT 별도) 또는 건수를 알려 주세요. 최소 집행은 {min_count:,}건({min_count * unit_price:,}원)이에요.",
        ))
        return result

    # 건수는 수수료를 빼기 전 총예산 기준 (amount.count_basis)
    if budget is not None:
        count = math.floor(budget / unit_price)
        supply = budget
    else:
        supply = count * unit_price
    result.update({"unit_price": unit_price, "count": count, "supply": supply})

    if count < min_count:
        result["status"] = "escalate"
        result["messages"].append(_message(
            f"약 {count:,}건이라 최소 집행 기준({min_count:,}건)에 못 미쳐요.",
            f"{product}는 {min_count:,}건({min_count * unit_price:,}원)부터 집행해요.",
            "예산을 늘리거나, 그대로 진행을 원하시면 담당자가 확인한 뒤 회신드려요.",
        ))
        return result

    fee = 0
    if requester == "agency":
        if fee_requested is None:
            result["status"] = "ask"
            result["messages"].append(_message(
                "대행 수수료 지급 요청 여부가 없어요.",
                "대행사인데 수수료 언급이 없어서 입금액을 확정할 수 없어요.",
                "대행 수수료를 요청하시는지 알려 주세요.",
            ))
            return result
        if fee_requested:
            fee = math.floor(supply * rules["amount"]["agency_fee_rate"])

    net = supply - fee
    result.update({
        "fee": fee,
        "net": net,
        "deposit": round(net * (1 + rules["amount"]["vat_rate"])),
    })
    return result
