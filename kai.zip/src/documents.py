"""광고게재신청서와 세금계산서 발행 요청 파일 만들기.

저장된 값을 정해진 칸에 넣는 일이라 LLM을 쓰지 않는다. 금액은 validate.calc_amount 결과만 쓴다.
두 문서가 같은 값에서 나오므로 서로 금액이 어긋나지 않는다.

광고게재신청서는 templates/광고게재신청서_양식.xlsx 를 읽어 {{이름}} 자리에 값을 넣는다.
양식 파일의 서식(글꼴, 색, 칸 너비, 문구)은 엑셀에서 직접 고치면 그대로 반영된다.
"""
import re
from datetime import date
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from .rules_loader import load_rules
from .validate import calc_amount

CONTRACT_TEMPLATE = Path(__file__).resolve().parent.parent / "templates" / "광고게재신청서_양식.xlsx"
FEE_MARK = "#수수료"          # A열에 이 표시가 있는 줄은 대행 수수료가 있을 때만 보인다
_PLACEHOLDER = re.compile(r"\{\{(.+?)\}\}")

_THIN = Side(style="thin", color="808080")
_THICK = Side(style="medium", color="000000")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)
_LABEL_FILL = PatternFill("solid", fgColor="D9D9D9")
_TOTAL_FILL = PatternFill("solid", fgColor="FFFF00")
_MONEY = "#,##0"
_COMPANY_FIELDS = {"회사명": "name", "주소지": "address", "사업자등록번호": "biz_no", "대표자": "ceo",
                   "담당자": "manager", "담당부서": "dept", "연락처": "phone", "이메일": "email"}


def _amounts(case, rules):
    result = calc_amount(
        case["product"], budget=case.get("budget"), count=case.get("count"),
        requester=case["requester"], fee_requested=case.get("fee_requested"), rules=rules,
    )
    if result["status"] != "ok":
        raise ValueError("문서를 만들 수 없어요: " + result["messages"][0]["what"])
    return result


def ad_name(case, rules):
    doc = rules["documents"]
    return doc["ad_name"].format(
        service_name=rules["operator"]["service_name"],
        app_name=case["app_name"],
        product_label=doc["product_labels"][case["product"]],
    )


def _contract_date(case):
    # 계약일은 수식(TODAY)이 아니라 고정된 날짜로 적는다. 파일을 열 때마다 날짜가 바뀌면 안 된다
    return case.get("contract_date") or date.today().isoformat()


def contract_values(case, rules, amt):
    """양식의 {{이름}} 자리에 들어갈 값."""
    op, doc = rules["operator"], rules["documents"]
    vat = round(amt["supply"] * rules["amount"]["vat_rate"])
    v = {
        "계약일": _contract_date(case),
        "광고명": ad_name(case, rules), "광고상품": case["product"], "계약기간": doc["contract_period"],
        "계약금액": amt["supply"], "세액": vat, "정산금액": amt["supply"] + vat,
        "비고": f"약 {amt['count']:,}건 (단가 {amt['unit_price']:,}원)",
        "세금계산서발행일자": doc["contract"]["invoice_date"], "입금기한": doc["contract"]["payment_due"],
        "입금계좌": op["bank"], "세금계산서수신메일": case["tax_email"],
        "수수료율": round(rules["amount"]["agency_fee_rate"] * 100),
        "대행수수료": amt["fee"], "실입금액": amt["deposit"], "수수료안내": doc["contract"]["fee_note"],
        "광고목표": rules["products"][case["product"]]["conversion"], "연동형태": case.get("integration") or "-",
    }
    if case["requester"] == "agency":
        advertiser = case["advertiser"]
    else:
        advertiser = {"name": "신청사와 동일"}
    parties = {"신청사": case["applicant"], "광고주": advertiser, "운영사": {**op, "email": op["tax_email"]}}
    for party, data in parties.items():
        for label, key in _COMPANY_FIELDS.items():
            v[f"{party}.{label}"] = data.get(key) or "-"
    for i, clause in enumerate(doc["contract"]["clauses_summary"], 1):
        v[f"조항{i}"] = clause
    return v


class _Sheet:
    """기본 양식을 처음 만들 때만 쓰는 도우미.

    A열: 표시용(#수수료), B·J열: 바깥 테두리 안쪽 여백, C~I열: 내용 7칸.
    눈금선은 끄고, 문서 전체를 굵은 테두리로 두르고, 묶음 제목 아래에 굵은 줄을 긋는다.
    """

    FIRST, LAST = 3, 9          # 내용이 들어가는 C~I열
    FRAME_L, FRAME_R = 2, 10    # 바깥 테두리가 그려지는 B·J열

    def __init__(self, ws):
        self.ws, self.row = ws, 2          # 2행은 테두리 안쪽 위 여백
        ws.sheet_view.showGridLines = False
        for col, width in zip("ABCDEFGHIJ", (2, 2, 18, 26, 14, 20, 14, 22, 16, 2)):
            ws.column_dimensions[col].width = width
        self.top = self.row
        self.row += 1

    def _cell(self, col, value, label=False, fmt=None):
        c = self.ws.cell(row=self.row, column=col, value=value)
        c.border, c.alignment = _BORDER, Alignment(vertical="center", wrap_text=True)
        if label:
            c.fill, c.font = _LABEL_FILL, Font(bold=True)
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        if fmt:
            c.number_format = fmt
        return c

    def _merge(self, first_col, last_col):
        self.ws.merge_cells(start_row=self.row, start_column=first_col, end_row=self.row, end_column=last_col)

    def title(self, text):
        self._merge(self.FIRST, self.LAST)
        c = self.ws.cell(row=self.row, column=self.FIRST, value=text)
        c.font, c.alignment = Font(bold=True, size=18), Alignment(horizontal="center", vertical="center")
        self.ws.row_dimensions[self.row].height = 36
        self.row += 2

    def heading(self, text):
        self.row += 1
        for col in range(self.FIRST, self.LAST + 1):
            self.ws.cell(row=self.row, column=col).border = Border(bottom=_THICK)
        self.ws.cell(row=self.row, column=self.FIRST, value=text).font = Font(bold=True, size=11)
        self.row += 1

    def pairs(self, *items, fmt=None, mark=None):
        """(이름, 값) 묶음을 한 줄에 최대 3개까지. 마지막 값 칸은 I열까지 합친다."""
        col = self.FIRST
        for i, (label, value) in enumerate(items):
            self._cell(col, label, label=True)
            self._cell(col + 1, value, fmt=fmt)
            if i == len(items) - 1 and col + 1 < self.LAST:
                for extra in range(col + 2, self.LAST + 1):
                    self._cell(extra, None)
                self._merge(col + 1, self.LAST)
            col += 2
        if mark:
            self.ws.cell(row=self.row, column=1, value=mark)
        self.row += 1

    def table_row(self, values, label=False, fmts=None, fills=None):
        for i, value in enumerate(values):
            c = self._cell(self.FIRST + i, value, label=label, fmt=(fmts or {}).get(i))
            if fills and i in fills:
                c.fill, c.font = fills[i], Font(bold=True)
        self.row += 1

    def text(self, value, mark=None):
        self._merge(self.FIRST, self.LAST)
        c = self.ws.cell(row=self.row, column=self.FIRST, value=value)
        c.alignment = Alignment(wrap_text=True, vertical="top")
        if mark:
            self.ws.cell(row=self.row, column=1, value=mark)
        self.row += 1

    def frame(self):
        """문서 전체를 굵은 테두리로 두른다 (마지막 줄 아래 한 줄은 안쪽 여백)."""
        bottom = self.row
        for r in range(self.top, bottom + 1):
            for c in (self.FRAME_L, self.FRAME_R):
                self.ws.cell(row=r, column=c).border = Border(
                    left=_THICK if c == self.FRAME_L else None,
                    right=_THICK if c == self.FRAME_R else None,
                    top=_THICK if r == self.top else None,
                    bottom=_THICK if r == bottom else None)
        for c in range(self.FRAME_L + 1, self.FRAME_R):
            for r, name in ((self.top, "top"), (bottom, "bottom")):
                cell = self.ws.cell(row=r, column=c)
                b = cell.border
                sides = {k: getattr(b, k) for k in ("left", "right", "top", "bottom")}
                sides[name] = _THICK
                cell.border = Border(**sides)


def build_contract_template(path=CONTRACT_TEMPLATE, rules=None):
    """기본 양식 파일을 만든다. 이미 고쳐 쓴 양식을 덮어쓰지 않도록, 파일이 없을 때만 부른다."""
    rules = rules or load_rules()
    wb = Workbook()
    ws = wb.active
    ws.title = "광고게재신청서"
    s = _Sheet(ws)
    s.title("광 고 게 재 신 청 서")
    ws.cell(row=s.row, column=8, value="계약일 :").alignment = Alignment(horizontal="right")
    ws.cell(row=s.row, column=9, value="{{계약일}}").font = Font(bold=True)
    s.row += 1

    def company(party):
        s.pairs(("회사명", f"{{{{{party}.회사명}}}}"), ("주소지", f"{{{{{party}.주소지}}}}"))
        s.pairs(("사업자등록번호", f"{{{{{party}.사업자등록번호}}}}"), ("대표자", f"{{{{{party}.대표자}}}}"),
                ("담당자", f"{{{{{party}.담당자}}}}"))
        s.pairs(("담당부서", f"{{{{{party}.담당부서}}}}"), ("연락처", f"{{{{{party}.연락처}}}}"),
                ("이메일", f"{{{{{party}.이메일}}}}"))

    s.heading("1. 신청사")
    company("신청사")
    s.heading("2. 광고주 (신청사와 동일한 경우 생략)")
    company("광고주")
    s.heading("3. 운영사")
    company("운영사")

    s.heading("4. 계약 정보")
    money = {3: _MONEY, 4: _MONEY, 5: _MONEY}
    s.table_row(["광고명", "광고상품", "계약기간", "계약금액(VAT별도)", "세액", "정산금액(VAT포함)", "비고"], label=True)
    s.table_row(["{{광고명}}", "{{광고상품}}", "{{계약기간}}", "{{계약금액}}", "{{세액}}", "{{정산금액}}", "{{비고}}"],
                fmts=money)
    s.table_row(["합계", None, None, "{{계약금액}}", "{{세액}}", "{{정산금액}}", "-"], fmts=money,
                fills={0: _LABEL_FILL, 5: _TOTAL_FILL})

    s.heading("5. 광고대금 지급 관련 정보")
    s.pairs(("세금계산서 발행일자", "{{세금계산서발행일자}}"), ("입금 기한", "{{입금기한}}"))
    s.pairs(("입금계좌", "{{입금계좌}}"), ("세금계산서 수신 메일", "{{세금계산서수신메일}}"))
    s.pairs(("대행 수수료({{수수료율}}%)", "{{대행수수료}}"), fmt=_MONEY, mark=FEE_MARK)
    s.text("※ {{수수료안내}}", mark=FEE_MARK)
    s.pairs(("실입금액", "{{실입금액}}"), fmt=_MONEY)

    s.heading("■ 광고 목표 및 연동")
    s.pairs(("광고 목표 및 목적", "{{광고목표}}"), ("연동 형태", "{{연동형태}}"))

    s.heading("■ 광고 계약 내용 (요약)")
    for i in range(1, len(rules["documents"]["contract"]["clauses_summary"]) + 1):
        s.text(f"{i}) {{{{조항{i}}}}}")

    s.heading("6. 서명")
    s.table_row(["신청인", None, "(날인)", None, "운영사", None, "(날인)"], label=True)
    s.table_row(["회사명", "{{신청사.회사명}}", None, None, "회사명", "{{운영사.회사명}}", None],
                fills={0: _LABEL_FILL, 4: _LABEL_FILL})
    s.table_row(["대표이사", "{{신청사.대표자}}", None, None, "대표이사", "{{운영사.대표자}}", None],
                fills={0: _LABEL_FILL, 4: _LABEL_FILL})
    # 날인 자리: (날인) 아래 두 칸을 합쳐 도장 찍을 공간을 만든다
    for col in (5, 9):
        ws.merge_cells(start_row=s.row - 2, start_column=col, end_row=s.row - 1, end_column=col)
    s.frame()

    ws.page_setup.orientation, ws.page_setup.fitToWidth, ws.page_setup.fitToHeight = "portrait", 1, 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def make_contract(case, path, rules=None, template=CONTRACT_TEMPLATE):
    """양식 파일의 {{이름}} 자리에 값을 넣어 광고게재신청서(엑셀)를 path에 저장한다."""
    rules = rules or load_rules()
    amt = _amounts(case, rules)
    values = contract_values(case, rules, amt)
    if not Path(template).exists():
        build_contract_template(template, rules)

    wb = load_workbook(template)
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            mark = row[0].value
            if mark == FEE_MARK:
                row[0].value = None
                if not amt["fee"]:
                    # 수수료가 없으면 그 줄을 비우고 숨긴다 (줄을 지우면 아래 서식이 어긋난다)
                    for cell in row:
                        if type(cell).__name__ != "MergedCell":
                            cell.value = None
                    ws.row_dimensions[row[0].row].hidden = True
                    continue
            for cell in row:
                if not isinstance(cell.value, str) or "{{" not in cell.value:
                    continue
                whole = _PLACEHOLDER.fullmatch(cell.value.strip())
                if whole:
                    # 칸 전체가 {{이름}} 하나면 숫자는 숫자 그대로 넣는다 (엑셀 서식이 적용되도록)
                    cell.value = values.get(whole.group(1).strip(), cell.value)
                else:
                    cell.value = _PLACEHOLDER.sub(
                        lambda m: str(values.get(m.group(1).strip(), m.group(0))), cell.value)
    wb.save(path)
    return amt


TAX_COLUMNS = (
    ["전자(세금)계산서 종류", "작성일자", "공급자 등록번호", "공급자 종사업장번호", "공급자 상호", "공급자 성명",
     "공급자 사업장주소", "공급자 업태", "공급자 종목", "공급자 이메일", "공급받는자 등록번호",
     "공급받는자 종사업장번호", "공급받는자 상호", "공급받는자 성명", "공급받는자 사업장주소", "공급받는자 업태",
     "공급받는자 종목", "공급받는자 이메일1", "공급받는자 이메일2", "공급가액", "세액", "비고"]
    + [f"{name}{n}" for n in range(1, 5)
       for name in ("일자", "품목", "규격", "수량", "단가", "공급가액", "세액", "품목비고")]
    + ["현금", "수표", "어음", "외상미수금", "영수(01)/청구(02)"]
)


def _digits(text):
    return "".join(ch for ch in str(text or "") if ch.isdigit())


def make_tax_invoice_request(case, path, rules=None):
    """재무팀에 전달하는 세금계산서 발행 요청 파일(일괄 등록 양식, 한 캠페인 = 한 줄)."""
    rules = rules or load_rules()
    amt, op, tax = _amounts(case, rules), rules["operator"], rules["documents"]["tax_invoice"]
    # 대행 수수료가 있어도 공급가액은 수수료를 빼기 전 총예산 (tax_invoice.amount_basis)
    supply = amt["supply"]
    vat = round(supply * rules["amount"]["vat_rate"])
    day = _digits(_contract_date(case))
    buyer = case["applicant"]

    row = dict.fromkeys(TAX_COLUMNS)
    row.update({
        "전자(세금)계산서 종류": tax["type_code"], "작성일자": day,
        "공급자 등록번호": _digits(op["biz_no"]), "공급자 상호": op["name"], "공급자 성명": op["ceo"],
        "공급자 사업장주소": op["address"], "공급자 업태": op["biz_type"], "공급자 종목": op["biz_item"],
        "공급자 이메일": op["tax_email"],
        "공급받는자 등록번호": _digits(buyer.get("biz_no")), "공급받는자 상호": buyer.get("name"),
        "공급받는자 성명": buyer.get("ceo"), "공급받는자 사업장주소": buyer.get("address"),
        "공급받는자 업태": buyer.get("biz_type"), "공급받는자 종목": buyer.get("biz_item"),
        "공급받는자 이메일1": case["tax_email"],
        "공급가액": supply, "세액": vat,
        "일자1": day[-2:], "품목1": ad_name(case, rules), "공급가액1": supply, "세액1": vat,
        "영수(01)/청구(02)": tax["receipt_code"],
    })

    wb = Workbook()
    ws = wb.active
    ws.title = "엑셀업로드양식"
    for col, name in enumerate(TAX_COLUMNS, 1):
        head = ws.cell(row=1, column=col, value=name)
        head.font, head.fill, head.border = Font(bold=True), _LABEL_FILL, _BORDER
        cell = ws.cell(row=2, column=col, value=row[name])
        cell.border = _BORDER
        if isinstance(row[name], (int, float)):
            cell.number_format = _MONEY
        ws.column_dimensions[head.column_letter].width = max(12, len(name) * 2)
    wb.save(path)
    return row
