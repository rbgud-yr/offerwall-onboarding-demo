"""광고주 안내서. 글은 rules.yaml의 guide에 있고, 숫자 자리는 같은 파일의 규칙 값으로 채운다."""


def _won(amount):
    """안내서의 금액은 짧게 읽히도록 만원 단위로 쓴다. 1,200,000 → 120만원"""
    return f"{amount // 10000:,}만원" if amount % 10000 == 0 else f"{amount:,}원"


def _values(rules):
    creative, policy = rules["rules"]["R8_creative"], rules["guide"]["policy"]
    return {
        "min_list": ", ".join(f"{name} {p['min_count']:,}건({_won(p['min_amount'])})" for name, p in rules["products"].items()),
        "fee_pct": round(rules["amount"]["agency_fee_rate"] * 100),
        "payment_due": rules["contract"]["payment_due"],
        "mmp_list": ", ".join(rules["rules"]["R6_cpe"]["mmp"]["options"]),
        "name_max": creative["campaign_name"]["max_chars"],
        "image_size": creative["image"]["size"].replace("x", "×"),
        # "도박, 사행성 (카지노 등)"에서 괄호 설명을 떼고 이름만 잇는다
        "prohibited": ", ".join(item.split(" (")[0].replace(", ", "·") for item in creative["review"]["prohibited_content"]),
        "lead_days": policy["lead_days"],
        "integration_days": policy["integration_days"],
        "creative_swaps": policy["creative_swaps_while_live"],
    }


def _fill(item, values):
    if isinstance(item, str):
        return item.format_map(values)
    if isinstance(item, list):
        return [_fill(x, values) for x in item]
    if isinstance(item, dict):
        return {k: _fill(v, values) for k, v in item.items()}
    return item


def build(rules):
    """화면에 보낼 안내서. 상품 비교표는 products 값으로 만든다."""
    g = rules["guide"]
    compare = [{"product": name, "label": rules["documents"]["product_labels"][name], "done_when": p["conversion"],
                "unit_price": p["unit_price"], "min_count": p["min_count"], "min_amount": p["min_amount"],
                "needs": g["compare_needs"][name]} for name, p in rules["products"].items()]
    return {"tab_name": g["tab_name"], "hero": g["hero"], "quick": g["quick"], "flow": g["flow"], "custom": g["custom_integration"],
            "chapters": _fill(g["chapters"], _values(rules)), "compare": compare}
