"""광고주가 낸 값 점검, 체크리스트 상태, 세팅 내역. 판정은 모두 rules.yaml 기준이고 LLM을 쓰지 않는다.

점검 함수는 {칸 이름: {what, why, how}} 를 돌려준다. 비어 있으면 통과다.
"""
import re
from datetime import date

from .validate import calc_amount

_HTTPS = re.compile(r"^https://\S+$")
OS_LABEL = {"aos": "Android", "ios": "iOS"}


def _msg(what, why, how):
    return {"what": what, "why": why, "how": how}


def _text(body, key):
    return str((body or {}).get(key) or "").strip()


def amount(terms, rules):
    agency = terms.get("actor") == "agency"
    fee = terms.get("fee")
    return calc_amount(
        terms.get("product"), budget=terms.get("budget") or None,
        requester="agency" if agency else "advertiser",
        fee_requested=(fee == "yes") if agency and fee in ("yes", "no") else None, rules=rules)


def check_terms(terms, rules):
    errors, agency = {}, terms.get("actor") == "agency"
    if terms.get("actor") not in ("agency", "direct"):
        errors["actor"] = _msg("신청 주체를 선택해 주세요.", "주체에 따라 입력 항목과 금액 계산이 달라져요.",
                               "광고주 직접 또는 대행사를 골라 주세요.")
    for key, label in (("company", "대행사 이름" if agency else "회사 이름"), ("app", "앱 이름")):
        if not _text(terms, key):
            errors[key] = _msg(f"{label}이 비어 있어요.", "신청서와 캠페인 세팅에 들어가요.", f"{label}을 입력해 주세요.")
    if agency and not _text(terms, "advertiser"):
        errors["advertiser"] = _msg("광고주(앱 운영사) 이름이 비어 있어요.", "대행사 캠페인은 실광고주 정보가 필요해요.",
                                    "광고주 이름을 입력해 주세요.")
    if terms.get("product") not in rules["rules"]["R3_product"]["supported"]:
        errors["product"] = _msg("캠페인 상품을 선택해 주세요.", "상품에 따라 단가와 연동 방식이 달라져요.",
                                 "CPI 또는 CPE를 골라 주세요.")
        return errors
    result = amount(terms, rules)
    if result["status"] != "ok":
        key = "fee" if agency and terms.get("fee") not in ("yes", "no") else "budget"
        errors[key] = result["messages"][0]
    return errors


def link_mode(test):
    """CPE 링크를 받은 방식. per_os: OS별 링크 / one: 링크 하나 + 노출 OS 직접 선택."""
    return "one" if (test or {}).get("link_mode") == "one" else "per_os"


def check_test(product, body, rules):
    errors = {}
    if product == "CPI":
        r5 = rules["rules"]["R5_cpi"]["validation"]
        ids = {os_: _text(body, os_) for os_ in OS_LABEL}
        if not any(ids.values()):
            errors["aos"] = _msg("Android 패키지명이나 iOS 앱스토어 ID 중 하나는 있어야 해요.",
                                 "캠페인 세팅과 리워드 지급 확인에 필요해요.", "진행하는 OS의 식별자를 입력해 주세요.")
        if ids["aos"] and not re.match(r5["app_id_aos"], ids["aos"]):
            errors["aos"] = _msg("패키지명 형식이 맞지 않아요.", "점(.)으로 구분된 형태여야 해요.", "예: com.example.app")
        if ids["ios"] and not re.match(r5["app_id_ios"], ids["ios"], re.I):
            errors["ios"] = _msg("앱스토어 ID 형식이 맞지 않아요.", "앱스토어 주소에서 id 뒤의 숫자예요.", "예: 1234567890")
        for os_, label in OS_LABEL.items():
            url, key = _text(body, os_ + "_url"), os_ + "_url"
            if ids[os_] and not url:
                errors[key] = _msg(f"{label} 랜딩 URL이 비어 있어요.", f"{label} 캠페인 세팅에 필요해요.", "https:// 로 시작하는 주소를 입력해 주세요.")
            elif url and not _HTTPS.match(url):
                errors[key] = _msg("주소 형식이 맞지 않아요.", "전체 주소가 있어야 이동할 수 있어요.", "https:// 로 시작하는 전체 주소를 입력해 주세요.")
            elif url and not ids[os_] and os_ not in errors:
                errors[os_] = _msg(f"{label} 랜딩 URL만 있고 식별자가 없어요.", "식별자와 랜딩 URL은 OS별로 함께 필요해요.",
                                   f"{label} 식별자도 입력해 주세요.")
    else:
        r6, integ, later = rules["rules"]["R6_cpe"], _text(body, "integ"), bool(body.get("later_link"))
        link_label = "최종 클릭 링크" if integ == "mmp" else "랜딩 URL"
        if integ not in r6["integration_type"]:
            errors["integ"] = _msg("연동 방식을 선택해 주세요.", "CPE는 앱 실행을 추적해야 해서 연동이 필요해요.",
                                   "사용 중인 MMP가 있으면 MMP 연동을, 없으면 서버 연동을 골라 주세요.")
        else:
            if integ == "mmp":
                if _text(body, "mmp") not in r6["mmp"]["options"]:
                    errors["mmp"] = _msg("사용 중인 MMP를 선택해 주세요.", "지금은 목록에 있는 MMP로만 연동할 수 있어요.",
                                         "목록에 없는 MMP를 쓰신다면 담당자에게 문의해 주세요.")
            if link_mode(body) == "one":
                # 링크 하나가 OS를 알아서 나누는 경우. 링크만으로는 OS를 알 수 없어 직접 고르게 한다
                link = _text(body, "one_link")
                if not later and not link:
                    errors["one_link"] = _msg(f"{link_label}가 비어 있어요.", "테스트를 시작하려면 필요해요.",
                                              "주소를 입력하거나 '나중에 올릴게요'를 선택해 주세요.")
                elif link and not later and not _HTTPS.match(link):
                    errors["one_link"] = _msg("주소 형식이 맞지 않아요.", "전체 주소가 있어야 테스트할 수 있어요.",
                                              "https:// 로 시작하는 전체 주소를 입력해 주세요.")
                if not any(body.get("one_" + os_) for os_ in OS_LABEL):
                    errors["one_os"] = _msg("노출할 OS를 선택해 주세요.", "링크가 하나면 어느 OS에 노출할지 링크만으로 알 수 없어요.",
                                            "Android, iOS 중 진행하는 OS를 모두 골라 주세요.")
            else:
                # 링크를 OS별로 따로 받는 경우 (식별자는 받지 않는다). 진행하는 OS만 입력
                links = {os_: _text(body, os_ + "_link") for os_ in OS_LABEL}
                if not later and not any(links.values()):
                    errors["aos_link"] = _msg(f"{link_label}가 비어 있어요.", "테스트를 시작하려면 필요해요.",
                                              "진행하는 OS의 주소를 입력하거나 '나중에 올릴게요'를 선택해 주세요.")
                for os_, link in links.items():
                    if link and not later and not _HTTPS.match(link):
                        errors[os_ + "_link"] = _msg("주소 형식이 맞지 않아요.", "전체 주소가 있어야 테스트할 수 있어요.",
                                                     "https:// 로 시작하는 전체 주소를 입력해 주세요.")
            if integ == "custom":
                auth = _text(body, "auth")
                if auth not in r6["auth_method_options"]:
                    errors["auth"] = _msg("인증 방식을 선택해 주세요.", "포스트백을 받을 때 보낸 쪽을 확인하는 방법이에요.",
                                          "개발 담당자와 확인해 골라 주세요.")
                elif auth == "ip_whitelist" and not _text(body, "server_ip"):
                    errors["server_ip"] = _msg("서버 IP가 비어 있어요.", "허용할 서버를 등록해야 해요.", "포스트백을 보내는 서버의 IP를 입력해 주세요.")
    for key, label in (("tname", "테스트 담당자 이름"), ("tphone", "테스트 담당자 연락처")):
        if not _text(body, key):
            errors[key] = _msg(f"{label}이 비어 있어요.", "테스트 중 확인할 일이 생기면 연락드려요.", f"{label}을 입력해 주세요.")
    return errors


def check_creative(product, body, has_image, rules):
    errors, r8 = {}, rules["rules"]["R8_creative"]
    name, limit = _text(body, "cname"), r8["campaign_name"]["max_chars"]
    if not name:
        errors["cname"] = _msg("캠페인 이름이 비어 있어요.", "유저에게 보이는 제목이에요.", f"{limit}자 이내로 입력해 주세요.")
    elif len(name) > limit:
        errors["cname"] = _msg(f"캠페인 이름이 {len(name)}자예요.", f"공백을 포함해 {limit}자까지 노출돼요.", f"{len(name) - limit}자를 줄여 주세요.")
    if not _text(body, "cdesc"):
        errors["cdesc"] = _msg("소개·참여방법이 비어 있어요.", "유저가 무엇을 하면 리워드를 받는지 알 수 있어야 해요.", "앱 소개와 참여방법을 적어 주세요.")
    if not _text(body, "ccaution"):
        errors["ccaution"] = _msg("유의사항이 비어 있어요.", "리워드가 지급되지 않는 경우를 미리 알려야 문의가 줄어요.",
                                  "기본 문구를 그대로 쓰거나 고쳐서 입력해 주세요.")
    day = _text(body, "opendate")
    try:
        if date.fromisoformat(day) < date.today():
            errors["opendate"] = _msg("오픈 일정이 지난 날짜예요.", "오늘 이후에만 오픈할 수 있어요.", "오늘 이후 날짜를 골라 주세요.")
    except ValueError:
        errors["opendate"] = _msg("오픈 일정을 선택해 주세요.", "소재 검수와 세팅 일정을 맞추는 기준이에요.",
                                  "소재는 오픈 3영업일 전까지 필요해요.")
    cap = _text(body, "daily_cap").replace(",", "")
    if cap and not (cap.isdigit() and int(cap) > 0):
        errors["daily_cap"] = _msg("데일리캡은 숫자로 입력해 주세요.", "하루에 참여할 수 있는 건수의 상한이에요.",
                                   "예: 500. 제한이 필요 없으면 비워 두세요.")
    if not has_image and not body.get("later_image"):
        errors["image"] = _msg("소재 이미지가 없어요.", "광고 목록에 보이는 이미지예요.", "이미지를 올리거나 '나중에 올릴게요'를 선택해 주세요.")
    return errors


def check_image(path, rules):
    """소재 이미지 규격 점검. 맞지 않는 점을 모두 돌려준다."""
    from PIL import Image

    spec, problems = rules["rules"]["R8_creative"]["image"], []
    try:
        with Image.open(path) as img:
            size, fmt = "%dx%d" % img.size, (img.format or "").lower()
    except Exception:
        return [_msg("이미지 파일을 열 수 없어요.", "파일이 손상됐거나 이미지가 아니에요.", "이미지 파일로 다시 올려 주세요.")]
    if spec.get("format") and fmt != spec["format"]:
        problems.append(_msg(f"{fmt.upper() or '알 수 없는'} 형식이에요.", f"{spec['format'].upper()} 형식만 등록할 수 있어요.",
                             f"{spec['format'].upper()}로 저장해 다시 올려 주세요."))
    if size != spec["size"]:
        problems.append(_msg(f"크기가 {size.replace('x', '×')}이에요.", "광고 목록에서 잘리거나 흐려져요.",
                             f"{spec['size'].replace('x', '×')}으로 맞춰 주세요."))
    kb = path.stat().st_size / 1024
    if spec.get("max_kb") and kb > spec["max_kb"]:
        problems.append(_msg(f"용량이 {kb:.0f}KB예요.", "용량이 크면 광고가 느리게 떠요.", f"{spec['max_kb']}KB 이하로 줄여 주세요."))
    return problems


def later_items(case):
    """광고주가 '나중에 올릴게요'로 미뤄 둔 항목."""
    items, test, creative = [], case.get("test") or {}, case.get("creative") or {}
    if test.get("later_link"):
        items.append("최종 클릭 링크" if test.get("integ") == "mmp" else "랜딩 URL")
    if creative.get("later_image"):
        items.append("소재 이미지")
    return items


def checklist(case, rules):
    """rules.yaml의 체크리스트 순서대로 완료 여부와 '지금 할 수 있는지'를 계산한다."""
    checks = case.get("checks") or {}
    submitted = all(case.get(k) for k in ("contract", "test", "creative"))
    done = {
        "terms": bool(case.get("confirmed")), "contract": bool(case.get("contract")),
        "sealadv": bool(case.get("seal_adv")), "sealops": bool(case.get("seal_ops")),
        "testinfo": bool(case.get("test")), "setup": bool(case.get("creative")) and not case.get("creative_reject"),   # 반려되면 다시 광고주의 할 일이 된다
        "later": submitted and not later_items(case),
    }
    items = []
    for spec in rules["onboarding_flow"]["checklist"]:
        key = spec["key"]
        needs = spec.get("needs", [])
        if isinstance(needs, str):
            # 오픈은 "위 항목 전부"가 조건이다
            needs = [i["key"] for i in items] if key == "open" else [needs]
        is_done = done[key] if key in done else bool(checks.get(key))
        items.append({"key": key, "name": spec["name"], "who": spec["who"], "note": spec.get("note"),
                      "done": is_done, "ready": all(i["done"] for i in items if i["key"] in needs),
                      # 아직 끝나지 않은 앞 단계의 이름. 왜 체크할 수 없는지 화면에서 알려 주는 데 쓴다
                      "waiting": [i["name"] for i in items if i["key"] in needs and not i["done"]],
                      "at": checks.get(key)})
    return items


def os_of(case):
    """노출 OS. CPI는 앱 식별자를, CPE는 링크를 낸 OS다. CPE 링크가 하나면 광고주가 고른 OS다."""
    test, cpi = case.get("test") or {}, case["terms"].get("product") == "CPI"
    if not cpi and link_mode(test) == "one":
        return [o for o in OS_LABEL if test.get("one_" + o)]
    return [o for o in OS_LABEL if test.get(o + ("" if cpi else "_link"))]


def default_cautions(product, rules):
    """유의사항 기본 문구 (rules.yaml). 광고주가 고쳐 쓸 수 있다."""
    spec = rules["rules"]["R8_creative"]["default_cautions"]
    return "\n".join("- " + line for line in [spec["first"].get(product, "")] + spec["common"] if line)


def check_setup(body, case):
    """운영자가 정하는 세팅 값: 운영 기간, 데일리캡, 운영 메모."""
    errors, start, end = {}, _text(body, "start_date"), _text(body, "end_date")
    try:
        date.fromisoformat(start)
    except ValueError:
        errors["start_date"] = _msg("시작일을 선택해 주세요.", "광고주에게 운영 기간을 알려야 해요.", "캠페인을 여는 날짜를 골라 주세요.")
    if end:
        try:
            if "start_date" not in errors and date.fromisoformat(end) < date.fromisoformat(start):
                errors["end_date"] = _msg("종료일이 시작일보다 빨라요.", "운영 기간은 시작일부터 종료일까지예요.", "시작일 이후 날짜를 골라 주세요.")
        except ValueError:
            errors["end_date"] = _msg("종료일 형식이 맞지 않아요.", "날짜로 입력해야 해요.", "날짜를 다시 골라 주세요. 정하지 않았으면 비워 두세요.")
    cap = _text(body, "daily_cap").replace(",", "")
    if cap and not (cap.isdigit() and int(cap) > 0):
        errors["daily_cap"] = _msg("데일리캡은 숫자로 입력해 주세요.", "하루 참여 건수의 상한이에요.",
                                   "기간별로 다르게 운영하면 처음 값을 넣고 운영 메모에 적어 주세요.")
    return errors


def period_text(setup):
    if not setup:
        return None
    return f"{setup['start_date']} ~ {setup.get('end_date') or '소진 시까지'}"


def cap_text(cap):
    return f"하루 {cap:,}건" if cap else "설정 안 함"


def setup_rows(case, rules, amt):
    """어드민에 옮겨 넣을 세팅 내역. 저장된 값에서 만들고 사람이 다시 입력하지 않는다."""
    t, test, cr = case["terms"], case.get("test") or {}, case.get("creative") or {}
    setup = case.get("setup") or {}
    agency, cpi = t.get("actor") == "agency", t.get("product") == "CPI"
    blank = lambda v: v or "(미입력)"
    integ = None
    if not cpi and test.get("integ"):
        auth = {"api_key": "API 키", "ip_whitelist": "IP 허용 목록"}.get(test.get("auth"), "인증 방식 미입력")
        integ = f"MMP · {blank(test.get('mmp'))}" if test["integ"] == "mmp" else f"서버 연동 · {auth}"
    if link_mode(test) == "one":
        links = f"OS 공통: {test['one_link']}" if test.get("one_link") else ""
    else:
        links = "\n".join(f"{OS_LABEL[o]}: {test[o + '_link']}" for o in OS_LABEL if test.get(o + "_link"))
    image = next((f["name"] for f in reversed(case.get("files", [])) if f["id"] == cr.get("image_file_id")), None)
    values = {
        "광고주": t.get("advertiser") if agency else t.get("company"),
        "대행사": t.get("company") if agency else None,
        "앱": t.get("app"),
        "상품 / 단가": f"{t.get('product')} / 단가 {amt.get('unit_price', '-')}원",
        "광고비 / 물량": f"{amt['supply']:,}원 / 약 {amt['count']:,}건" if amt.get("status") == "ok" else None,
        "노출 OS": ", ".join(OS_LABEL[o] for o in os_of(case)),
        "Android 패키지명": blank(test.get("aos")) if cpi else None,
        "Android 랜딩 URL": blank(test.get("aos_url")) if cpi else None,
        "iOS 앱스토어 ID": blank(test.get("ios")) if cpi else None,
        "iOS 랜딩 URL": blank(test.get("ios_url")) if cpi else None,
        "연동 방식": None if cpi else blank(integ),
        "랜딩 URL 또는 최종 클릭 링크": None if cpi else ("(나중에 제출)" if test.get("later_link") else blank(links)),
        "캠페인명": blank(cr.get("cname")),
        "소개 문구": blank(cr.get("cdesc")),
        "유의사항": blank(cr.get("ccaution")),
        "소재 이미지": "(나중에 제출)" if cr.get("later_image") else blank(image),
        "오픈 일정": blank(cr.get("opendate")),
        "데일리캡": cap_text(cr.get("daily_cap")),
        "운영 기간": blank(period_text(setup)),
        "확정 데일리캡": cap_text(setup.get("daily_cap")) if setup else "(미입력)",
        "운영 메모": setup.get("memo") or None,
    }
    rows = []
    for label in rules["onboarding_flow"]["setup_notice"]["rows"]:
        if values.get(label, "") is not None:
            rows.append([label, blank(values.get(label))])
    return rows


# 문구 속 리워드 금액 (예: 500원, 100포인트). AI 초안 검사와 운영자 검수 표시가 같이 쓴다
REWARD_AMOUNT = re.compile(r"\d[\d,]*\s*(원|포인트|P\b|p\b|캐시|코인)")


def creative_flags(case):
    """운영자가 소재를 검수할 때 눈여겨볼 점. 제출을 막지는 않는다 (금액을 쓸지는 광고주가 정한다)."""
    cr, flags = case.get("creative") or {}, []
    for key, label in (("cname", "캠페인 이름"), ("cdesc", "소개 · 참여방법")):
        found = REWARD_AMOUNT.search(cr.get(key) or "")
        if found:
            flags.append(f"{label}에 리워드 금액이 있어요: \"{found.group(0)}\". 실제 지급액과 맞는지 확인해 주세요.")
    return flags


def seen_stamps(case):
    """광고주가 낸 것마다 '언제 낸 것인지'. 운영자가 본 뒤 다시 내면 값이 달라진다."""
    confirm = next((l["at"] for l in reversed(case.get("log") or []) if l.get("text") == "협의 내용 확정"), None)
    stamp = lambda key, field: (case.get(key) or {}).get(field)
    return {"terms": confirm if case.get("confirmed") else None,
            "contract": stamp("contract", "submitted_at"), "sealadv": stamp("seal_adv", "uploaded_at"),
            "test": stamp("test", "submitted_at"), "creative": stamp("creative", "submitted_at")}


def adv_unseen(case):
    """광고주가 아직 보지 않은, 운영사에서 온 것. 지금은 양사 날인이 끝난 최종본 하나다."""
    seal = case.get("seal_ops")
    return ["sealops"] if seal and (case.get("adv_seen") or {}).get("sealops") != seal.get("uploaded_at") else []


def unseen(case):
    """운영자가 아직 보지 않은 광고주 제출. 알림이 없는 대신 화면을 열었을 때 무엇이 새로 왔는지 보여준다."""
    seen = case.get("ops_seen") or {}
    return [key for key, at in seen_stamps(case).items() if at and seen.get(key) != at]


# ── 제출 뒤의 수정: 무엇이 바뀌었는지, 무엇을 못 바꾸는지 ──
FIELD_LABELS = {
    "contract": {"name": "회사명", "ceo": "대표자", "biz_no": "사업자등록번호", "biz_type": "업태", "biz_item": "종목",
                 "address": "사업장 주소", "manager": "담당자 이름", "dept": "담당부서", "phone": "담당자 연락처",
                 "email": "담당자 이메일", "report_email": "리포트 확인용 구글 계정"},
    "test": {"aos": "Android 패키지명", "aos_url": "Android 랜딩 URL", "ios": "iOS 앱스토어 ID", "ios_url": "iOS 랜딩 URL",
             "integ": "연동 방식", "mmp": "MMP", "link_mode": "링크 전달 방식", "aos_link": "Android 링크", "ios_link": "iOS 링크",
             "one_link": "링크", "one_aos": "노출 OS", "one_ios": "노출 OS", "later_link": "링크 나중에 올리기",
             "auth": "인증 방식", "server_ip": "서버 IP", "tname": "테스트 담당자", "tphone": "테스트 담당자 연락처"},
    "creative": {"cname": "캠페인 이름", "cdesc": "소개 · 참여방법", "ccaution": "유의사항", "opendate": "오픈 일정",
                 "daily_cap": "데일리캡", "image_file_id": "소재 이미지", "later_image": "소재 이미지"},
}
REQUEST_TARGETS = {"terms": "협의 내용", "seal": "날인본", "tax_email": "세금계산서 수신 메일", "contract": "계약 정보",
                   "test": "테스트 정보", "creative": "광고 소재"}


def changed_fields(kind, old, new):
    """다시 제출했을 때 달라진 항목의 이름. 운영자가 예전 값으로 일하지 않게 이력에 남긴다."""
    if kind == "contract":
        flat = lambda c: {**(c.get("applicant") or {}), "report_email": c.get("report_email")}
        old, new = flat(old), flat(new)
    names = [label for key, label in FIELD_LABELS[kind].items() if (old.get(key) or "") != (new.get(key) or "")]
    return [n for i, n in enumerate(names) if n not in names[:i]]


def locks(case):
    """광고주가 지금 바꿀 수 없는 것. 운영자가 수정 요청을 받고 열어 주면 한 번 다시 낼 수 있다."""
    opened, sealed = case.get("unlocked") or {}, bool(case.get("seal_adv"))
    checks = case.get("checks") or {}
    tested, set_up = bool(checks.get("test")), bool(checks.get("adminset"))     # 연동 테스트 통과, 캠페인 세팅 완료
    if checks.get("open"):                         # 캠페인을 오픈하면 전부 잠근다. 열어 준 것도 소용없다
        opened = {}
    return {"terms": bool(case.get("confirmed")) and sealed,     # 확정했더라도 날인본을 올리기 전까지는 고칠 수 있다
            "tax_email": bool(case.get("contract")),
            "seal": sealed and not opened.get("seal"),
            "contract": sealed and not opened.get("contract"),
            # 테스트한 값은 테스트가 끝나면, 소재는 운영자가 세팅을 끝내면 바꿀 수 없다 (처음 내는 것은 언제든 된다).
            # 소재 검수는 AI가 바로 끝내므로 잠금 기준으로 쓰지 않는다. 그 전에 고치면 AI가 다시 검수한다
            "test": bool(case.get("test")) and tested and not opened.get("test"),
            "creative": bool(case.get("creative")) and set_up and not opened.get("creative")}
