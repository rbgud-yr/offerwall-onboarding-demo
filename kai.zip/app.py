"""서버. 화면의 부탁을 받아 규칙 적용, AI 호출, 저장, 문서 생성을 한다 (docs/구조.md).

켜기: python app.py  →  브라우저에서 http://127.0.0.1:5000
광고주 화면: /a/{캠페인 번호}    운영자 화면: /ops
"""
import hashlib
import hmac
import json
import re
from datetime import date
from pathlib import Path

from flask import Flask, Response, abort, jsonify, redirect, request, send_file

from src import intake, store
from src.documents import make_contract, make_tax_invoice_request
from src.llm.biz_cert import FIELDS as CERT_FIELDS
from src.llm.biz_cert import read_biz_cert
from src.app_info import fetch_app_info, intro_from, source_urls
from src.llm.creative_ideas import find_points, name_problems, review_copy, suggest_creative
from src.llm.review import check_final_seal, check_seal, review_creative
from src.guide import build as build_guide
from src.rules_loader import load_rules
from src.validate import check_biz_no

ROOT = Path(__file__).resolve().parent
app = Flask(__name__, static_folder=str(ROOT / "web"), static_url_path="/static")
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024    # 올리는 파일은 10MB까지
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0           # 화면 파일을 브라우저가 기억해 두지 않게. 고친 화면이 새로고침만으로 보이도록


@app.after_request
def _no_cache(resp):
    """화면(HTML, 스크립트, 스타일)은 매번 새로 받아 가게 한다. 예전 화면이 남아 헷갈리지 않도록 (시연용 서버)."""
    if resp.mimetype in ("text/html", "text/css", "application/javascript", "text/javascript"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


def _demo_password():
    """시연 링크를 다른 사람에게 열 때 쓰는 비밀번호. .env의 KAI_DEMO_PASSWORD. 없으면 잠금이 꺼져 있다 (혼자 쓸 때)."""
    path = ROOT / ".env"
    if path.exists():
        for line in path.read_text(encoding="utf-8-sig").splitlines():
            if line.strip().startswith("KAI_DEMO_PASSWORD="):
                return line.split("=", 1)[1].strip()
    return ""


DEMO_PASSWORD = _demo_password()


@app.before_request
def _lock():
    """비밀번호가 정해져 있으면 모든 화면과 요청에 비밀번호를 묻는다. 로그인이 없는 시연용 서버를 링크로 열 때의 최소한의 잠금."""
    if not DEMO_PASSWORD:
        return None
    auth = request.authorization
    if auth and hmac.compare_digest((auth.password or "").encode(), DEMO_PASSWORD.encode()):
        return None
    return Response("비밀번호가 필요해요.", 401, {"WWW-Authenticate": 'Basic realm="kai demo", charset="UTF-8"'})

# 시연용 예시 캠페인. 모두 가상 값. 예산을 비워 두면 상품의 최소 집행 금액이 들어간다
PRESETS = {
    "agency_cpi": {"actor": "agency", "company": "블루핀애드", "advertiser": "모닝루틴",
                   "app": "모닝루틴", "product": "CPI", "budget": None, "fee": "yes"},
    "direct_cpe": {"actor": "direct", "company": "가상게임즈", "advertiser": "",
                   "app": "던전메이트", "product": "CPE", "budget": 2000000, "fee": ""},
    "direct_cpa": {"actor": "direct", "company": "가상커머스", "advertiser": "",
                   "app": "오늘장보기", "product": "CPA", "budget": None, "fee": ""},
    # 시연에서 앱 정보 가져오기를 보여주기 위한 캠페인. 누구나 아는 공개 앱을 예시로 쓰며 실제 광고주가 아니다 (회사명은 가상)
    "demo_kakao": {"actor": "direct", "company": "가상광고주", "advertiser": "",
                   "app": "카카오톡", "product": "CPI", "budget": None, "fee": ""},
    "blank": {"actor": "", "company": "", "advertiser": "", "app": "", "product": "", "budget": None, "fee": ""},
}
TERM_KEYS = ("actor", "company", "advertiser", "app", "product", "budget", "fee")
TERM_LABELS = {"actor": "신청 주체", "company": "회사", "advertiser": "광고주", "app": "앱",
               "product": "상품", "budget": "예산", "fee": "대행 수수료"}
OPS_CHECKS = ("approval", "invoice", "paid", "test", "adminset", "report", "open")
_EMAIL = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
_IMAGE_TYPES = {".png", ".jpg", ".jpeg", ".webp"}


def _msg(what, why, how):
    return {"what": what, "why": why, "how": how}


def _clean_terms(body, rules):
    terms = {k: str((body or {}).get(k) or "").strip() for k in TERM_KEYS if k != "budget"}
    digits = re.sub(r"[^0-9]", "", str((body or {}).get("budget") or ""))
    terms["budget"] = int(digits) if digits else None
    if terms["budget"] is None and terms["product"] in rules["products"]:
        terms["budget"] = rules["products"][terms["product"]]["min_amount"]   # 기본값은 최소 집행 금액
    if terms["actor"] != "agency":
        terms["advertiser"], terms["fee"] = "", ""
    return terms


def _view(case):
    """화면에 보내는 캠페인 기록. 금액·체크리스트·세팅 내역은 저장하지 않고 열 때마다 rules.yaml로 계산한다."""
    rules = load_rules()
    amount = intake.amount(case["terms"], rules)
    return {**case, "amount": amount, "fee_rate": rules["amount"]["agency_fee_rate"],
            "checklist": intake.checklist(case, rules), "later": intake.later_items(case),
            "setup_rows": intake.setup_rows(case, rules, amount),
            "creative_spec": rules["rules"]["R8_creative"],
            "app_info_url": (source_urls(case) or [""])[0],
            "max_points": rules["rules"]["R8_creative"]["proposal"]["max_selected_points"],
            "mmp_options": rules["rules"]["R6_cpe"]["mmp"]["options"],
            "min_amounts": {name: p["min_amount"] for name, p in rules["products"].items()},
            "os": intake.os_of(case),
            "creative_flags": intake.creative_flags(case),
            "unseen": intake.unseen(case),
            # 운영자가 한 번 본 뒤에 다시 낸 것은 '새로 제출됨'이 아니라 '수정됨'으로 보여준다
            "adv_unseen": intake.adv_unseen(case),
            "unseen_changed": [k for k in intake.unseen(case) if (case.get("ops_seen") or {}).get(k)],
            "locks": intake.locks(case),
            # 대행 수수료가 있을 때 대행사가 수수료분 세금계산서를 발행하는 데 필요한 것
            "fee_invoice": {"text": rules["operator"]["fee_invoice_request"], "to": rules["operator"]["name"],
                            "tax_email": rules["operator"]["tax_email"],
                            "files": [[k, f["label"]] for k, f in rules["operator"]["files"].items()]},
            "default_cautions": intake.default_cautions(case["terms"].get("product"), rules)
            if case["terms"].get("product") in rules["products"] else "",
            "report_admin_url": rules["operator"]["report_admin_url"],
            "bank": rules["operator"]["bank"],          # 입금 계좌. 광고주 진행 현황과 입금 안내에 보인다
            "guide": build_guide(rules)}


def _case_or_404(case_id):
    try:
        return store.load(case_id)
    except KeyError:
        abort(404)


def _ok(case):
    store.save(case)
    return jsonify({"ok": True, "case": _view(case)})


def _fail(errors, status=400):
    return jsonify({"ok": False, "errors": errors}), status


def _save_upload(case, upload, kind, allowed):
    """올린 파일을 저장하고 파일 기록을 돌려준다. 형식이 맞지 않으면 None."""
    ext = Path(upload.filename).suffix.lower() if upload and upload.filename else ""
    if ext not in allowed:
        return None, None
    file_id = store.next_id(case["files"], "F")
    path = store.folder("uploads", case["id"]) / f"{file_id}{ext}"
    upload.save(path)
    item = {"id": file_id, "kind": kind, "name": upload.filename, "stored": path.name, "uploaded_at": store.now()}
    case["files"].append(item)
    return item, path


# ── 화면 ────────────────────────────────────────────
@app.route("/")
def home():
    return redirect("/ops")


@app.route("/ops")
def ops_page():
    return send_file(ROOT / "web" / "ops.html")


@app.route("/start")
def advertiser_start():
    """광고주가 스스로 새 캠페인을 시작하는 주소. 빈 캠페인을 만들고 그 광고주 화면(안내서)으로 보낸다.
    링크 하나를 여러 사람에게 보내도 각자 자기 캠페인이 생긴다 (사용자 테스트용). 협의 내용은 광고주가 직접 채운다."""
    case = store.new_case(_clean_terms(PRESETS["blank"], load_rules()))
    return redirect(f"/a/{case['id']}")


@app.route("/a/<case_id>")
def advertiser_page(case_id):
    _case_or_404(case_id)
    return send_file(ROOT / "web" / "advertiser.html")


# ── 캠페인, 협의 내용 ───────────────────────────────────
@app.route("/api/cases")
def list_cases():
    return jsonify([_view(c) for c in store.list_cases()])


@app.route("/api/cases", methods=["POST"])
def create_case():
    preset = PRESETS.get((request.get_json(silent=True) or {}).get("preset"))
    if preset is None:
        abort(400)
    return jsonify(_view(store.new_case(_clean_terms(preset, load_rules()))))


@app.route("/api/cases/<case_id>")
def get_case(case_id):
    return jsonify(_view(_case_or_404(case_id)))


@app.route("/api/cases/<case_id>/seen", methods=["POST"])
def mark_seen(case_id):
    """운영자가 광고주의 제출을 봤다고 남긴다. 그 뒤로는 '새로 제출됨' 표시가 사라진다."""
    case = _case_or_404(case_id)
    stamps = intake.seen_stamps(case)
    for key in (request.get_json(silent=True) or {}).get("keys") or []:
        if stamps.get(key):
            case.setdefault("ops_seen", {})[key] = stamps[key]
    store.save(case)
    return jsonify({"ok": True})


@app.route("/api/cases/<case_id>/adv-seen", methods=["POST"])
def mark_adv_seen(case_id):
    """광고주가 운영사에서 온 것(최종 날인본)을 봤다고 남긴다. 그 뒤로는 '최종본 도착' 표시가 사라진다."""
    case = _case_or_404(case_id)
    if "sealops" in ((request.get_json(silent=True) or {}).get("keys") or []) and case.get("seal_ops"):
        case.setdefault("adv_seen", {})["sealops"] = case["seal_ops"]["uploaded_at"]
        store.save(case)
    return jsonify({"ok": True})


# ── 수정 요청: 광고주가 못 바꾸는 항목을 글로 요청하고, 운영자가 처리한다 ──
@app.route("/api/cases/<case_id>/requests", methods=["POST"])
def send_request(case_id):
    case = _case_or_404(case_id)
    body = request.get_json(silent=True) or {}
    target, text = body.get("target"), str(body.get("text") or "").strip()
    if target not in intake.REQUEST_TARGETS:
        return _fail({"_form": _msg("수정 요청을 받을 수 없는 항목이에요.", "", "화면을 새로고침한 뒤 다시 시도해 주세요.")})
    if (case.get("checks") or {}).get("open"):
        return _fail({"text": _msg("캠페인이 오픈된 뒤에는 바꿀 수 없어요.", "오픈하면 모든 정보가 잠겨서 수정 요청을 받지 않아요.",
                                   "꼭 필요하면 담당자에게 따로 연락해 주세요.")})
    if any(r["target"] == target and r["status"] == "open" for r in case["requests"]):
        return _fail({"text": _msg("이미 보낸 요청이 있어요.", "운영사가 아직 확인하고 있어요.", "처리된 뒤에 다시 요청해 주세요.")})
    if len(text) < 5:
        return _fail({"text": _msg("요청 내용이 비어 있어요.", "무엇을 어떻게 바꿀지 알아야 처리할 수 있어요.",
                                   "바꿀 항목과 바꿀 값을 적어 주세요.")})
    case["requests"].append({"id": store.next_id(case["requests"], "Q"), "target": target, "text": text,
                             "at": store.now(), "status": "open", "reply": "", "done_at": None, "result": None})
    _log(case, "광고주", f"{intake.REQUEST_TARGETS[target]} 수정 요청")
    return _ok(case)


@app.route("/api/cases/<case_id>/requests/<request_id>", methods=["POST"])
def handle_request(case_id, request_id):
    """운영자: 반영(apply) / 다시 낼 수 있게 열기(unlock) / 반영하지 않음(reject)."""
    case = _case_or_404(case_id)
    body = request.get_json(silent=True) or {}
    item = next((r for r in case["requests"] if r["id"] == request_id and r["status"] == "open"), None) or abort(404)
    action, reply, target = body.get("action"), str(body.get("reply") or "").strip(), item["target"]
    label = intake.REQUEST_TARGETS[target]
    if action != "reject" and (case.get("checks") or {}).get("open"):
        return _fail({"_form": _msg("오픈한 캠페인은 수정 요청을 반영하거나 열어 줄 수 없어요.", "오픈하면 모든 정보가 잠겨요.",
                                    "'반영하지 않음'으로 닫아 주세요. 꼭 바꿔야 하면 캠페인 오픈 체크를 먼저 풀어 주세요.")})
    if action == "apply" and target == "tax_email":
        value = str(body.get("value") or "").strip()
        if not _EMAIL.match(value):
            return _fail({"value": _msg("새 메일 주소 형식이 맞지 않아요.", "세금계산서를 받을 주소예요.", "name@company.com 형태로 입력해 주세요.")})
        _log(case, "운영자", f"{label} 변경: {case['contract']['tax_email']} → {value} (광고주 요청)")
        case["contract"]["tax_email"] = value
        _make_docs(case, only="tax_invoice")          # 날인한 신청서는 그대로 두고 발행 요청 파일만 새로 만든다
        result = "반영했어요"
    elif action == "apply" and target == "terms":
        # 확정된 협의 내용은 운영자만 고친다. 운영자가 계약·서류에서 고친 뒤 요청을 닫는다
        _log(case, "운영자", f"{label} 수정 요청을 반영함")
        result = "반영했어요"
    elif action == "unlock" and target in ("seal", "contract", "test", "creative"):
        case.setdefault("unlocked", {})[target] = True
        _log(case, "운영자", f"{label}을(를) 다시 낼 수 있게 열어 줌 (광고주 요청)")
        result = "다시 제출할 수 있게 열어 드렸어요"
    elif action == "reject":
        if not reply:
            return _fail({"reply": _msg("답변이 비어 있어요.", "반영하지 않는 이유를 광고주가 알아야 해요.", "이유를 적어 주세요.")})
        _log(case, "운영자", f"{label} 수정 요청을 반영하지 않음")
        result = "반영하지 않았어요"
    else:
        return _fail({"_form": _msg("이 요청에 쓸 수 없는 처리예요.", "", "화면을 새로고침한 뒤 다시 시도해 주세요.")})
    # 승인(반영했거나 다시 낼 수 있게 열어 줌)인지 반려인지 따로 남겨 화면에서 한눈에 구분한다
    item.update(status="done", result=result, reply=reply, done_at=store.now(), verdict="rejected" if action == "reject" else "approved")
    return _ok(case)


@app.route("/api/cases/<case_id>/requests-seen", methods=["POST"])
def mark_replies_seen(case_id):
    """광고주가 수정 요청의 답변을 봤다고 남긴다. 그 뒤로는 메뉴의 '승인', '반려' 표시가 사라진다."""
    case = _case_or_404(case_id)
    ids = set((request.get_json(silent=True) or {}).get("ids") or [])
    for r in case["requests"]:
        if r["id"] in ids and r["status"] == "done":
            r["seen_by_advertiser"] = True
    store.save(case)
    return jsonify({"ok": True})


@app.route("/api/operator-files/<kind>")
def operator_file(kind):
    """운영사 서류 (가상 견본). rules.yaml에 적힌 두 가지만 내려준다."""
    item = load_rules()["operator"]["files"].get(kind) or abort(404)
    path = ROOT / item["path"]
    if not path.exists():
        abort(404)
    return send_file(path, as_attachment=True, download_name=path.name)


@app.route("/api/calc", methods=["POST"])
def calc():
    """입력 중인 협의 내용의 금액을 미리 계산해 준다 (저장하지 않음)."""
    rules = load_rules()
    terms = _clean_terms(request.get_json(silent=True), rules)
    return jsonify({"terms": terms, "amount": intake.amount(terms, rules),
                    "fee_rate": rules["amount"]["agency_fee_rate"]})


@app.route("/api/cases/<case_id>/terms", methods=["POST"])
def save_terms(case_id):
    """확정 전: 광고주·운영자 모두 수정. 확정 후: 광고주는 날인본을 올리기 전까지, 운영자는 언제든 수정하고 변경 이력을 남긴다."""
    case, rules = _case_or_404(case_id), load_rules()
    body = request.get_json(silent=True) or {}
    by, confirm = body.get("by", "advertiser"), bool(body.get("confirm"))
    if by != "operator" and intake.locks(case)["terms"]:
        return _fail({"_form": _msg("날인본을 올린 뒤에는 협의 내용을 바꿀 수 없어요.", "날인한 신청서와 내용이 달라지면 안 돼요.",
                                    "바꿔야 하면 수정 요청을 보내 주세요.")})
    terms = _clean_terms(body.get("terms"), rules)
    errors = intake.check_terms(terms, rules) if (confirm or case["confirmed"]) else {}
    if errors:
        return _fail(errors)

    old = case["terms"]
    changed = [k for k in TERM_KEYS if old.get(k) != terms.get(k)]
    case["terms"] = terms
    if case["confirmed"] and changed:
        case.setdefault("log", []).append({
            "at": store.now(), "by": "운영자" if by == "operator" else "광고주",
            "text": "협의 내용 수정: " + ", ".join(f"{TERM_LABELS[k]}: {old.get(k) or '(없음)'} → {terms.get(k) or '(없음)'}" for k in changed)})
        # 협의 내용이 바뀌면 신청서, 날인, 운영자 체크를 다시 해야 한다.
        # 세금계산서 발행과 입금 확인은 계약보다 먼저 끝났을 수 있으므로, 금액에 영향이 없는 수정이면 그대로 둔다
        money = {"actor", "product", "budget", "fee"} & set(changed)
        kept = {} if money else {k: v for k, v in case["checks"].items() if k in ("invoice", "paid")}
        case["seal_adv"], case["seal_ops"], case["checks"] = None, None, kept
        if "product" in changed:
            case["test"] = None
        _make_docs(case)
    if confirm and not case["confirmed"]:
        case["confirmed"] = True
        case.setdefault("log", []).append({"at": store.now(), "by": "광고주", "text": "협의 내용 확정"})
        _make_docs(case)
    return _ok(case)


# ── 사업자등록증 올리기 → AI 읽기 ─────────────────────
@app.route("/api/cases/<case_id>/biz-cert", methods=["POST"])
def upload_biz_cert(case_id):
    case = _case_or_404(case_id)
    upload = request.files.get("file")
    if not upload or not upload.filename:
        return jsonify({"status": "failed", "reason": "파일이 없어요.", "fields": {}}), 400
    item, path = _save_upload(case, upload, "biz_cert", _IMAGE_TYPES | {".pdf"})
    if not item:
        return jsonify({"status": "failed", "fields": {},
                        "reason": "PDF, PNG, JPG 파일만 자동으로 읽을 수 있어요. 아래 칸에 직접 입력해 주세요."})

    result = read_biz_cert(path)
    run_id = store.next_id(case["ai_runs"], "R")
    case["ai_runs"].append({
        "id": run_id, "task": "biz_cert", "file_id": item["id"], "at": store.now(),
        "status": result["status"], "reason": result.get("reason"),
        "model": result.get("model"), "seconds": result.get("seconds"),
        "cost_usd": result.get("cost_usd"),
        "read": result.get("fields", {}),     # AI가 읽은 원본 값
        "confirmed": None,                    # 사람이 확인해 제출한 값 (제출할 때 채운다)
    })
    store.save(case)
    return jsonify({**result, "file_id": item["id"], "run_id": run_id})


@app.route("/api/cases/<case_id>/files/<file_id>")
def get_file(case_id, file_id):
    case = _case_or_404(case_id)
    item = next((f for f in case["files"] if f["id"] == file_id), None) or abort(404)
    return send_file(store.folder("uploads", case_id) / item["stored"])


# ── 계약 정보 제출 → 저장 → 문서 생성 ─────────────────
def _check_contract(body, case):
    errors = {}
    applicant = {k: str(v or "").strip() for k, v in (body.get("applicant") or {}).items()}

    required = {
        "name": "회사명", "ceo": "대표자", "address": "사업장 주소", "biz_type": "업태",
        "biz_item": "종목", "manager": "담당자 이름", "phone": "담당자 연락처",
    }
    for key, label in required.items():
        if not applicant.get(key):
            errors[key] = _msg(f"{label}이(가) 비어 있어요.",
                               "광고게재신청서와 세금계산서에 들어가는 값이에요.",
                               "사업자등록증을 올리면 자동으로 채워지고, 직접 입력해도 돼요."
                               if key in CERT_FIELDS else f"{label}을(를) 입력해 주세요.")

    biz = check_biz_no(applicant.get("biz_no"))
    if biz["ok"]:
        applicant["biz_no"] = biz["formatted"]
    else:
        errors["biz_no"] = biz["message"]

    emails = {"email": ("담당자 이메일", applicant.get("email")),
              "tax_email": ("세금계산서 수신 메일", str(body.get("tax_email") or "").strip()),
              "report_email": ("리포트 로그인용 구글 계정", str(body.get("report_email") or "").strip())}
    for key, (label, value) in emails.items():
        if not _EMAIL.match(value or ""):
            errors[key] = _msg(f"{label} 형식이 맞지 않아요.",
                               "@와 도메인이 있어야 메일을 받을 수 있어요.",
                               "name@company.com 형태로 입력해 주세요.")

    contract = {"applicant": applicant, "tax_email": emails["tax_email"][1],
                "report_email": emails["report_email"][1]}
    return contract, errors


def _log(case, by, text):
    case.setdefault("log", []).append({"at": store.now(), "by": by, "text": text})


def _log_change(case, kind, label, old, new):
    """광고주가 이미 낸 것을 다시 냈으면 무엇이 달라졌는지 이력에 남긴다."""
    if old:
        fields = intake.changed_fields(kind, old, new)
        _log(case, "광고주", f"{label} 수정: {', '.join(fields)}" if fields else f"{label} 다시 제출 (바뀐 값 없음)")


def _make_docs(case, only=None):
    """협의 내용이 확정되고 계약 정보가 있으면 문서 두 개를 새로 만든다. 예전 문서는 지우지 않는다.
    only를 주면 그 종류만 만든다 (예: 날인이 끝난 뒤 세금계산서 메일만 바뀐 경우).

    둘 중 하나라도 없으면 아무것도 하지 않는다 (입력 순서는 자유라서 어느 쪽이 먼저 올지 모른다).
    """
    if not (case["confirmed"] and case["contract"]):
        return []
    rules = load_rules()
    t, c = case["terms"], case["contract"]
    agency = t["actor"] == "agency"
    test = case.get("test") or {}
    doc_case = {
        "requester": "agency" if agency else "advertiser",
        "fee_requested": (t["fee"] == "yes") if agency else None,
        "product": t["product"], "budget": t["budget"], "app_name": t["app"],
        "contract_date": date.today().isoformat(), "tax_email": c["tax_email"],
        "applicant": c["applicant"],
        "advertiser": {"name": t["advertiser"]} if agency else None,
        "integration": {"mmp": "MMP 연동", "custom": "직연동(서버 연동)"}.get(test.get("integ")),
    }
    out = store.folder("docs", case["id"])
    round_no = len(case["docs"]) // 2 + 1
    amount = intake.amount(t, rules)
    made = []
    for kind, label, maker in (("contract", "광고게재신청서", make_contract),
                               ("tax_invoice", "세금계산서발행요청", make_tax_invoice_request)):
        if only and kind != only:
            continue
        doc_id = store.next_id(case["docs"], "D")
        maker(doc_case, out / f"{doc_id}.xlsx", rules)
        doc = {"id": doc_id, "kind": kind, "name": f"{label}_{t['app']}_{round_no}.xlsx",
               "stored": f"{doc_id}.xlsx", "created_at": store.now(),
               "contract_date": doc_case["contract_date"],
               # 문서에는 만든 시점의 금액을 함께 남긴다. 규칙이 바뀌어도 이미 만든 문서의 금액은 그대로다
               "amounts": {k: amount[k] for k in ("supply", "fee", "deposit", "count")}}
        case["docs"].append(doc)
        made.append(doc)
    return made


@app.route("/api/cases/<case_id>/contract", methods=["POST"])
def submit_contract(case_id):
    case = _case_or_404(case_id)
    body, old = request.get_json(silent=True) or {}, case.get("contract")
    if intake.locks(case)["contract"]:
        return _fail({"_form": _msg("날인본을 올린 뒤에는 계약 정보를 바꿀 수 없어요.", "날인한 신청서와 내용이 달라지면 안 돼요.",
                                    "바꿔야 하면 수정 요청을 보내 주세요.")})
    if old:
        body = {**body, "tax_email": old["tax_email"]}     # 세금계산서 수신 메일은 한 번 내면 끝이다
    contract, errors = _check_contract(body, case)
    if errors:
        return _fail(errors)

    contract["submitted_at"] = store.now()
    _log_change(case, "contract", "계약 정보", old, contract)
    case.setdefault("unlocked", {}).pop("contract", None)
    case["contract"] = contract
    # 신청서를 새로 만들므로 예전 날인본과 품의는 더 이상 맞지 않는다.
    # 세금계산서 발행과 입금 확인은 계약 정보보다 먼저 끝났을 수 있으므로 그대로 둔다
    case["seal_adv"], case["seal_ops"] = None, None
    case["checks"].pop("approval", None)
    # AI가 읽은 값과 사람이 확정한 값을 나란히 남겨, 얼마나 정확히 읽었는지 나중에 볼 수 있게 한다
    run = next((r for r in reversed(case["ai_runs"]) if r["id"] == body.get("run_id")), None)
    if run:
        run["confirmed"] = {k: contract["applicant"].get(k) for k in CERT_FIELDS}
    docs = _make_docs(case)
    store.save(case)
    return jsonify({"ok": True, "docs": docs, "case": _view(case)})


@app.route("/api/cases/<case_id>/seal", methods=["POST"])
def upload_seal(case_id):
    """광고주: 날인한 신청서. 운영자(by=operator): 운영사까지 날인한 최종본."""
    case = _case_or_404(case_id)
    final = request.form.get("by") == "operator"
    contract_doc = next((d for d in reversed(case["docs"]) if d["kind"] == "contract"), None)
    if not contract_doc:
        return _fail({"_form": _msg("아직 신청서가 만들어지지 않았어요.",
                                    "협의 내용 확정과 계약 정보 제출이 모두 끝나야 신청서가 만들어져요.",
                                    "두 가지를 먼저 끝내 주세요.")})
    again = bool(case.get("seal_adv"))
    if not final and intake.locks(case)["seal"]:
        return _fail({"_form": _msg("날인본은 한 번 올리면 바꿀 수 없어요.", "이미 내부 품의가 진행 중일 수 있어요.",
                                    "바꿔야 하면 수정 요청을 보내 주세요.")})
    item, path = _save_upload(case, request.files.get("file"), "seal_ops" if final else "seal_adv",
                              _IMAGE_TYPES | {".pdf"})
    if not item:
        return _fail({"_form": _msg("올릴 수 없는 파일 형식이에요.", "날인본은 스캔본이나 사진으로 받아요.",
                                    "PDF, PNG, JPG 파일로 올려 주세요.")})
    ai_check = None
    if not final:
        # 날인본은 한 번 내면 끝이다. 잘못 올린 것을 그 자리에서 알려 주려고 AI가 먼저 본다. 광고주가 그래도 내겠다면 받는다
        forced = request.form.get("force") == "1"
        result = {"status": "skipped"} if forced else check_seal(path, case["contract"]["applicant"].get("name"))
        _ai_run(case, "seal_check", result) if not forced else None
        if result["status"] == "ok":
            ai_check = result["check"]
            if not (ai_check["is_application"] and ai_check["has_seal"]):
                case["files"].pop()
                path.unlink()
                store.save(case)
                what = "광고게재신청서가 아닌 것 같아요." if not ai_check["is_application"] else "날인(도장이나 서명)이 보이지 않아요."
                return jsonify({"ok": False, "seal_check": ai_check, "errors": {"_form": _msg(
                    what, "날인본은 한 번 내면 바꿀 수 없어서 미리 확인했어요. " + ai_check["note"],
                    "파일을 확인해 다시 올려 주세요. 맞는 파일이라면 '이대로 제출'을 눌러 주세요.")}}), 400
        elif forced:
            ai_check = {"forced": True}
    final_check = None
    if final:
        # 최종본은 올리는 즉시 광고주에게 전달된다. 운영사 날인이 빠진 파일을 보내지 않도록 AI가 먼저 본다. 운영자가 맞다고 하면 받는다
        if request.form.get("force") == "1":
            final_check = {"forced": True}
        else:
            result = check_final_seal(path, case["contract"]["applicant"].get("name"), load_rules()["operator"]["name"])
            _ai_run(case, "final_seal_check", result)
            if result["status"] == "ok":
                final_check = result["check"]
                if not (final_check["is_application"] and final_check["advertiser_seal"] and final_check["operator_seal"]):
                    case["files"].pop()
                    path.unlink()
                    store.save(case)
                    what = ("광고게재신청서가 아닌 것 같아요." if not final_check["is_application"]
                            else "운영사 날인이 보이지 않아요." if not final_check["operator_seal"] else "광고주 날인이 보이지 않아요.")
                    return jsonify({"ok": False, "seal_check": final_check, "errors": {"_form": _msg(
                        what, "최종본은 올리는 즉시 광고주에게 전달돼서 미리 확인했어요. " + final_check["note"],
                        "양사 날인이 모두 있는 파일을 다시 올려 주세요. 맞는 파일이라면 '이대로 전달'을 눌러 주세요.")}}), 400
                if final_check["note"]:
                    # 날인은 있어 보이지만 AI가 확인할 점을 남겼다. 보내고 나서 알려 주면 늦으니, 운영자가 확인하고 직접 보내게 멈춘다
                    case["files"].pop()
                    path.unlink()
                    store.save(case)
                    return jsonify({"ok": False, "seal_check": final_check, "errors": {"_form": _msg(
                        "보내기 전에 확인해 주세요.", final_check["note"],
                        "파일을 확인하고 맞으면 '이대로 전달'을 눌러 주세요. 아니면 다른 파일을 올려 주세요.")}}), 400
    # 어느 신청서에 날인한 것인지 함께 남긴다
    case["seal_ops" if final else "seal_adv"] = {
        "file_id": item["id"], "name": item["name"], "doc_id": contract_doc["id"], "uploaded_at": store.now()}
    if final:
        case["seal_ops"]["ai_check"] = final_check      # 운영자 화면에 AI가 본 결과를 보여준다
    if not final:
        case["seal_adv"]["ai_check"] = ai_check          # 운영자 화면에 AI가 본 결과를 함께 보여준다
        if again:
            _log(case, "광고주", f"날인본 다시 올림: {item['name']}")
        case.setdefault("unlocked", {}).pop("seal", None)
    return _ok(case)


@app.route("/api/cases/<case_id>/docs/<doc_id>")
def get_doc(case_id, doc_id):
    case = _case_or_404(case_id)
    doc = next((d for d in case["docs"] if d["id"] == doc_id), None) or abort(404)
    return send_file(store.folder("docs", case_id) / doc["stored"],
                     as_attachment=True, download_name=doc["name"])


# ── 연동·테스트, 광고 소재 ───────────────────────────
@app.route("/api/cases/<case_id>/test", methods=["POST"])
def submit_test(case_id):
    case, rules = _case_or_404(case_id), load_rules()
    body = request.get_json(silent=True) or {}
    product = case["terms"]["product"]
    if intake.locks(case)["test"]:
        return _fail({"_form": _msg("연동 테스트가 끝난 뒤에는 테스트 정보를 바꿀 수 없어요.", "테스트한 값과 달라지면 안 돼요.",
                                    "바꿔야 하면 수정 요청을 보내 주세요.")})
    errors = intake.check_test(product, body, rules)
    if errors:
        return _fail(errors)
    keys = ["aos", "aos_url", "ios", "ios_url"] if product == "CPI" else [
        "integ", "mmp", "aos_link", "ios_link", "one_link", "auth", "server_ip"]
    test = {k: str(body.get(k) or "").strip() for k in keys + ["tname", "tphone"]}
    test["later_link"] = bool(body.get("later_link")) and product != "CPI"
    if product != "CPI":
        # 고르지 않은 쪽의 값은 남기지 않는다 (화면에서 방식을 바꾸다 남은 값이 세팅 내역에 섞이지 않게)
        one = intake.link_mode(body) == "one"
        test["link_mode"] = "one" if one else "per_os"
        test["one_aos"], test["one_ios"] = (bool(body.get("one_aos")), bool(body.get("one_ios"))) if one else (False, False)
        if test["integ"] != "mmp":
            test["mmp"] = ""
        for key in ("aos_link", "ios_link") if one or test["later_link"] else ():
            test[key] = ""
        if not one or test["later_link"]:
            test["one_link"] = ""
    test["submitted_at"] = store.now()
    _log_change(case, "test", "테스트 정보", case.get("test"), test)
    case.setdefault("unlocked", {}).pop("test", None)
    case["test"] = test
    case["checks"].pop("test", None)      # 연동 정보가 바뀌면 테스트를 다시 해야 한다
    case["checks"].pop("adminset", None)
    return _ok(case)


# ── 소재 기획 도우미 (AI) ─────────────────────────────
def _ai_run(case, task, result):
    """AI를 부른 기록을 남기고 실행 번호를 돌려준다."""
    run_id = store.next_id(case["ai_runs"], "R")
    case["ai_runs"].append({
        "id": run_id, "task": task, "at": store.now(),
        "status": result["status"], "reason": result.get("reason"),
        "model": result.get("model"), "seconds": result.get("seconds"), "cost_usd": result.get("cost_usd"),
        "read": None, "confirmed": None,
    })
    return {"run_id": run_id, "at": store.now(), "model": result.get("model"),
            "seconds": result.get("seconds"), "cost_usd": result.get("cost_usd")}


def _need_product(case, rules):
    if case["terms"].get("product") not in rules["products"]:
        return _fail({"_form": _msg("상품이 아직 정해지지 않았어요.", "상품에 따라 제안이 달라져요.", "협의 내용에서 상품을 먼저 정해 주세요.")})


@app.route("/api/cases/<case_id>/ideas/app-info", methods=["POST"])
def load_app_info(case_id):
    """스토어의 앱 페이지에서 앱 소개 글의 재료를 가져온다. AI를 쓰지 않고, 저장하지도 않는다."""
    case, rules = _case_or_404(case_id), load_rules()
    spec = rules["rules"]["R8_creative"]["proposal"]["app_info"]
    url = str((request.get_json(silent=True) or {}).get("url") or "").strip()
    if url:
        info = fetch_app_info(url, spec)
        result = {"ok": True, "url": info["url"], "intro": (info["title"] + "\n" + info["description"]).strip()[: spec["max_intro_chars"]]} \
            if info["ok"] else {"ok": False, "tried": [{"url": url, "reason": info["reason"]}]}
    else:
        result = intro_from(case, rules)
    if not result["ok"]:
        tried = result.get("tried") or []
        return _fail({"url": _msg("앱 정보를 가져오지 못했어요.", tried[-1]["reason"] if tried else "읽어 볼 스토어 주소가 없어요.",
                                  "구글 플레이나 앱스토어의 앱 페이지 주소를 넣어 보거나, 아래 앱 소개를 직접 적어 주세요.")})
    return jsonify({"ok": True, "intro": result["intro"], "url": result["url"]})


def _intro_or_fail(case, rules, body):
    """소재 기획에 쓸 앱 소개. 상품이 없거나 소개가 너무 짧으면 AI를 부르지 않는다."""
    spec, intro = rules["rules"]["R8_creative"]["proposal"], str(body.get("intro") or "").strip()
    stop = _need_product(case, rules)
    if not stop and len(intro) < spec["min_intro_chars"]:
        stop = _fail({"intro": _msg("앱 소개가 너무 짧아요.", "AI는 여기 적힌 내용만 근거로 제안해요.",
                                    f"어떤 앱인지, 누가 쓰는지, 무엇이 좋은지 {spec['min_intro_chars']}자 이상 적어 주세요.")})
    return intro, stop


@app.route("/api/cases/<case_id>/ideas/points", methods=["POST"])
def suggest_points(case_id):
    """1단계: 앱 소개에서 소구 포인트 후보를 찾는다. 무엇을 내세울지는 광고주가 고른다."""
    case, rules = _case_or_404(case_id), load_rules()
    intro, stop = _intro_or_fail(case, rules, request.get_json(silent=True) or {})
    if stop:
        return stop
    result = find_points(case["terms"].get("app"), case["terms"]["product"], intro, rules)
    run = _ai_run(case, "creative_points", result)
    if result["status"] != "ok" or not result["points"]:
        store.save(case)
        return _fail({"_form": _msg("소구 포인트를 찾지 못했어요.", result.get("reason") or "", "잠시 후 다시 시도하거나 광고 소재를 직접 작성해 주세요.")})
    # 앱 소개가 바뀌어 후보를 다시 찾으면 예전 후보로 쓴 초안은 더 이상 맞지 않는다
    case["idea_points"] = {"intro": intro, "points": result["points"], **run}
    case["ideas"] = None
    return _ok(case)


@app.route("/api/cases/<case_id>/ideas", methods=["POST"])
def suggest_ideas(case_id):
    """2단계: 광고주가 고른 소구 포인트로 AI가 소재 초안을 쓴다. 초안은 참고용이고, 쓸지는 광고주가 고른다."""
    case, rules = _case_or_404(case_id), load_rules()
    body = request.get_json(silent=True) or {}
    most = rules["rules"]["R8_creative"]["proposal"]["max_selected_points"]
    intro, stop = _intro_or_fail(case, rules, body)
    if stop:
        return stop
    points = [str(p).strip()[:40] for p in (body.get("points") or []) if str(p).strip()]
    points = [p for i, p in enumerate(points) if p not in points[:i]]
    if not 1 <= len(points) <= most:
        return _fail({"points": _msg("소구 포인트를 골라 주세요." if not points else f"소구 포인트는 {most}개까지 고를 수 있어요.",
                                     "고른 포인트를 중심으로 초안을 써요.", f"1개 이상 {most}개 이하로 골라 주세요.")})

    result = suggest_creative(case["terms"].get("app"), case["terms"]["product"], intro, points, rules)
    run = _ai_run(case, "creative_ideas", result)
    if result["status"] != "ok":
        store.save(case)
        return _fail({"_form": _msg("AI 제안을 받지 못했어요.", result.get("reason") or "", "잠시 후 다시 시도하거나 광고 소재를 직접 작성해 주세요.")})
    # 다시 들어와도 볼 수 있게 마지막 제안을 남긴다
    case["ideas"] = {"intro": intro, "points": points, **run, **result["ideas"]}
    return _ok(case)


@app.route("/api/cases/<case_id>/ideas/review", methods=["POST"])
def review_my_copy(case_id):
    """광고주가 쓴 캠페인 이름과 소개를 제출 전에 점검한다. 규칙은 코드가, 표현은 AI가 본다."""
    case, rules = _case_or_404(case_id), load_rules()
    body = request.get_json(silent=True) or {}
    name, desc = str(body.get("cname") or "").strip(), str(body.get("cdesc") or "").strip()
    stop = _need_product(case, rules)
    if stop:
        return stop
    if not name:
        return _fail({"cname": _msg("캠페인 이름이 비어 있어요.", "점검할 문구가 있어야 해요.", "쓰려는 캠페인 이름을 적어 주세요.")})

    product = case["terms"]["product"]
    result = review_copy(case["terms"].get("app"), product, name, desc, rules)
    run = _ai_run(case, "creative_review", result)
    if result["status"] != "ok":
        store.save(case)
        return _fail({"_form": _msg("AI 점검을 받지 못했어요.", result.get("reason") or "", "잠시 후 다시 시도해 주세요. 점검 없이도 광고 소재는 제출할 수 있어요.")})
    case["review"] = {"cname": name, "cdesc": desc, **run, **result["review"],
                      # 규칙으로 확인되는 것은 AI 의견과 따로 보여준다
                      "rule_problems": name_problems(name, product, rules, strict_prefix=False)}
    return _ok(case)


@app.route("/api/cases/<case_id>/creative-image", methods=["POST"])
def upload_creative_image(case_id):
    case, rules = _case_or_404(case_id), load_rules()
    item, path = _save_upload(case, request.files.get("file"), "creative", {".png", ".jpg", ".jpeg", ".webp", ".gif"})
    if not item:
        return _fail({"image": _msg("이미지 파일이 아니에요.", "소재는 이미지 파일로 받아요.", "PNG, JPG 같은 이미지 파일을 올려 주세요.")})
    problems = intake.check_image(path, rules)
    if problems:
        case["files"].pop()                # 규격에 맞지 않는 이미지는 보관하지 않는다
        path.unlink()
        return jsonify({"ok": False, "problems": problems}), 400
    store.save(case)
    return jsonify({"ok": True, "file": item})


def _creative_key(creative):
    """검수받은 내용과 제출하는 내용이 같은지 견주는 값. 글자 하나라도 다르면 값이 달라진다."""
    parts = [str(creative.get(k) or "").strip() for k in ("cname", "cdesc", "ccaution", "image_file_id")]
    return hashlib.sha1(json.dumps(parts, ensure_ascii=False).encode("utf-8")).hexdigest()


@app.route("/api/cases/<case_id>/creative-review", methods=["POST"])
def review_creative_draft(case_id):
    """제출하기 전에 AI 검수를 받는다. 검수는 제출이 아니다. 광고주가 결과를 보고 고친 뒤 직접 제출한다."""
    case, rules = _case_or_404(case_id), load_rules()
    body = request.get_json(silent=True) or {}
    if intake.locks(case)["creative"]:
        return _fail({"_form": _msg("캠페인 세팅이 끝난 뒤에는 광고 소재를 바꿀 수 없어요.", "이 소재로 캠페인이 세팅됐어요.",
                                    "바꿔야 하면 수정 요청을 보내 주세요.")})
    image = next((f for f in case["files"] if f["id"] == body.get("image_file_id") and f["kind"] == "creative"), None)
    errors = intake.check_creative(case["terms"]["product"], {**body, "later_image": False}, bool(image), rules)
    if errors:
        return _fail(errors)
    creative = {"cname": body["cname"].strip(), "cdesc": body["cdesc"].strip(), "ccaution": body["ccaution"].strip(), "image_file_id": image["id"]}
    result = review_creative(store.folder("uploads", case["id"]) / image["stored"], case["terms"].get("app"),
                             case["terms"]["product"], creative, rules)
    run = _ai_run(case, "creative_check", result)
    draft = {"key": _creative_key(creative), **run}
    draft.update(result["review"] if result["status"] == "ok" else {"failed": result.get("reason") or "AI 검수를 하지 못했어요."})
    case["creative_draft_review"] = draft
    store.save(case)
    return jsonify({"ok": True, "review": draft})


def _attach_review(case):
    """제출한 내용이 검수받은 내용 그대로면 그 검수 결과를 붙인다. 소재에는 승인 단계가 없고, 결과는 운영자가 반려할지 정할 때 참고한다."""
    draft, case["creative_review"] = case.get("creative_draft_review"), None
    case["creative_draft_review"] = None
    if not draft or draft["key"] != _creative_key(case["creative"]):
        if case["creative"].get("image_file_id"):
            _log(case, "AI", "AI 검수를 받지 않았거나 검수 뒤에 내용이 바뀐 소재. 운영자 확인 필요")
        return
    case["creative_review"] = draft
    if draft.get("passed"):
        _log(case, "AI", "소재 검수 통과 (검수받은 내용 그대로 제출)")
    elif not draft.get("failed"):
        _log(case, "AI", f"소재 검수: 반려 대상 {len(draft['issues'])}건이 남은 채로 제출됨. 운영자 확인 필요")


def _review_creative(case, rules, image):
    """미룬 이미지를 나중에 올렸을 때의 AI 소재 검수. 결과는 운영자가 반려할지 정할 때 참고한다."""
    case["creative_review"] = None
    if not image or not rules["rules"]["R8_creative"]["review"]["by_ai"]:
        return
    result = review_creative(store.folder("uploads", case["id"]) / image["stored"], case["terms"].get("app"),
                             case["terms"]["product"], case["creative"], rules)
    run = _ai_run(case, "creative_review_auto", result)
    if result["status"] != "ok":
        case["creative_review"] = {"failed": result.get("reason") or "AI 검수를 하지 못했어요.", **run}
        _log(case, "AI", "소재 검수를 하지 못함. 운영자 확인 필요")
        return
    review = result["review"]
    case["creative_review"] = {**review, **run}
    _log(case, "AI", "소재 검수 통과" if review["passed"] else f"소재 검수: 반려 대상 {len(review['issues'])}건")


@app.route("/api/cases/<case_id>/creative", methods=["POST"])
def submit_creative(case_id):
    case, rules = _case_or_404(case_id), load_rules()
    body = request.get_json(silent=True) or {}
    image = next((f for f in case["files"] if f["id"] == body.get("image_file_id") and f["kind"] == "creative"), None)
    later = bool(body.get("later_image")) and not image
    old_creative = case.get("creative")
    image_only = False
    if intake.locks(case)["creative"]:
        # 캠페인 세팅이 끝나면 소재를 바꿀 수 없다. 다만 '나중에 올릴게요'로 미룬 이미지는 그것만 올릴 수 있다
        if not (old_creative.get("later_image") and image):
            return _fail({"_form": _msg("캠페인 세팅이 끝난 뒤에는 광고 소재를 바꿀 수 없어요.", "이 소재로 캠페인이 세팅됐어요.",
                                        "바꿔야 하면 수정 요청을 보내 주세요.")})
        body = {**{k: old_creative.get(k) for k in ("cname", "cdesc", "ccaution", "opendate", "daily_cap", "extra")}, "image_file_id": image["id"]}
        image_only, later = True, False
    errors = {} if image_only else intake.check_creative(case["terms"]["product"], {**body, "later_image": later}, bool(image), rules)
    if errors:
        return _fail(errors)
    case["creative"] = {
        "cname": body["cname"].strip(), "cdesc": body["cdesc"].strip(), "ccaution": body["ccaution"].strip(),
        "opendate": body["opendate"],
        "extra": str(body.get("extra") or "").strip(),
        "daily_cap": int(str(body.get("daily_cap")).replace(",", "")) if str(body.get("daily_cap") or "").strip() else None,
        "image_file_id": image["id"] if image else None, "later_image": later,
        "submitted_at": store.now()}
    _log_change(case, "creative", "광고 소재", old_creative, case["creative"])
    case["creative_reject"] = None          # 다시 내면 반려 상태가 풀린다
    case.setdefault("unlocked", {}).pop("creative", None)
    case["checks"].pop("adminset", None)
    # 미룬 이미지만 올린 경우에는 그 자리에서 검수하고, 그 밖에는 제출 전에 받은 검수 결과를 쓴다
    _review_creative(case, rules, image) if image_only else _attach_review(case)
    return _ok(case)


@app.route("/api/cases/<case_id>/creative-reject", methods=["POST"])
def reject_creative(case_id):
    """운영자가 광고 소재를 반려한다. 사유가 광고주에게 보이고, 광고주가 고쳐서 다시 내야 한다."""
    case = _case_or_404(case_id)
    reason = str((request.get_json(silent=True) or {}).get("reason") or "").strip()
    if not case.get("creative"):
        return _fail({"_form": _msg("아직 제출된 소재가 없어요.", "", "광고주가 소재를 제출한 뒤에 반려할 수 있어요.")})
    if (case.get("checks") or {}).get("open"):
        return _fail({"_form": _msg("오픈한 캠페인의 소재는 반려할 수 없어요.", "오픈하면 모든 정보가 잠겨요.", "꼭 필요하면 캠페인 오픈 체크를 먼저 풀어 주세요.")})
    if len(reason) < 2:
        return _fail({"reason": _msg("반려 사유가 비어 있어요.", "무엇을 고쳐야 하는지 광고주가 알아야 해요.", "사유를 적어 주세요.")})
    case["creative_reject"] = {"reason": reason, "at": store.now()}
    case["checks"].pop("adminset", None)     # 반려하면 세팅을 다시 해야 한다. 세팅이 풀리면 광고주가 소재를 고칠 수 있다
    _log(case, "운영자", f"광고 소재 반려: {reason}")
    return _ok(case)


# ── 운영자가 정하는 세팅 값, 오픈 후 게재지면 ─────────────
@app.route("/api/cases/<case_id>/setup", methods=["POST"])
def save_setup(case_id):
    """운영 기간·데일리캡·운영 메모. '캠페인 세팅 완료'를 체크하면 광고주 화면에 세팅 내역으로 보인다."""
    case = _case_or_404(case_id)
    body = request.get_json(silent=True) or {}
    errors = intake.check_setup(body, case)
    if errors:
        return _fail(errors)
    cap = str(body.get("daily_cap") or "").replace(",", "").strip()
    case["setup"] = {"start_date": body["start_date"], "end_date": str(body.get("end_date") or "").strip(),
                     "daily_cap": int(cap) if cap else None, "memo": str(body.get("memo") or "").strip(),
                     "saved_at": store.now()}
    return _ok(case)


@app.route("/api/cases/<case_id>/placement", methods=["POST"])
def upload_placement(case_id):
    """캠페인을 연 뒤 실제 게재된 화면의 캡처를 올리면 광고주 화면에 보인다."""
    case = _case_or_404(case_id)
    if not (case.get("checks") or {}).get("open"):
        return _fail({"_form": _msg("아직 캠페인을 열지 않았어요.", "게재지면은 오픈한 뒤의 화면이에요.", "캠페인 오픈을 먼저 체크해 주세요.")})
    item, _ = _save_upload(case, request.files.get("file"), "placement", _IMAGE_TYPES)
    if not item:
        return _fail({"_form": _msg("이미지 파일이 아니에요.", "게재지면은 화면 캡처로 받아요.", "PNG, JPG 이미지를 올려 주세요.")})
    return _ok(case)


# ── 운영자 체크 ─────────────────────────────────────
@app.route("/api/cases/<case_id>/check", methods=["POST"])
def set_check(case_id):
    case, rules = _case_or_404(case_id), load_rules()
    body = request.get_json(silent=True) or {}
    key, value = body.get("key"), bool(body.get("value"))
    if key not in OPS_CHECKS:
        abort(400)
    item = next(i for i in intake.checklist(case, rules) if i["key"] == key)
    if value and not item["ready"]:
        names = {i["key"]: i["name"] for i in intake.checklist(case, rules)}
        spec = next(s for s in rules["onboarding_flow"]["checklist"] if s["key"] == key)
        needs = spec.get("needs", [])
        waiting = "앞 단계 전부" if key == "open" else ", ".join(names[n] for n in ([needs] if isinstance(needs, str) else needs))
        return _fail({"_form": _msg(f"'{item['name']}'을(를) 아직 체크할 수 없어요.",
                                    f"먼저 끝나야 하는 단계가 있어요: {waiting}.",
                                    "앞 단계를 끝낸 뒤 다시 체크해 주세요.")})
    if value and key == "adminset" and not case.get("setup"):
        # [결정] 운영자가 고칠 값이 없으면 저장 없이 바로 체크한다. 이때는 광고주가 낸 오픈 일정과 데일리캡이 그대로 세팅 값이 된다
        creative = case.get("creative") or {}
        case["setup"] = {"start_date": creative.get("opendate") or "", "end_date": "", "daily_cap": creative.get("daily_cap"),
                         "memo": "", "saved_at": store.now()}
    if value:
        case["checks"][key] = store.now()
    else:
        case["checks"].pop(key, None)
        if key != "open":
            case["checks"].pop("open", None)   # 앞 단계를 풀면 오픈도 풀린다
    return _ok(case)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
