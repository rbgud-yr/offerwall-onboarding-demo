"""체험판용 AI 대역.

체험판은 서버도 API 키도 없이 브라우저 안에서 돈다. 그래서 AI를 부르는 자리에
시연 때 실제로 받은 답(replay.json)을 대신 돌려준다. 답을 받아 둔 조건(예시 캠페인, 예시 파일)과
다르면 "받아 둔 답이 없다"고 알리고, 프로그램은 원래대로 직접 입력·사람 확인 흐름으로 넘어간다.

AI가 낸 답을 코드가 다시 확인하는 부분(글자 수, 리워드 금액, 사업자번호 등)은 원래 코드가 그대로 한다.
"""
import base64
import copy
import hashlib
import re
from pathlib import Path

NO_RECORD = ("체험판은 AI를 실제로 부르지 않고, 예시 캠페인(모닝루틴)과 예시 파일로 받아 둔 답만 보여 줘요. "
             "'예시 파일 넣기' 버튼으로 올리면 저장된 결과를 볼 수 있어요.")
NO_RECORD_CREATIVE = ("체험판은 AI를 실제로 부르지 않아요. 모닝루틴 캠페인에서 소재 기획 도우미의 첫 번째 이름과 "
                      "첫 번째 소개, 예시 이미지를 그대로 쓰면 받아 둔 검수 결과를 볼 수 있어요.")
NO_STORE = "체험판은 스토어 페이지를 읽지 않아요. 예시 캠페인(모닝루틴)만 저장된 앱 소개를 보여 줘요."


def _sha(data):
    return hashlib.sha1(data).hexdigest()


def _between(text, tag):
    found = re.search(rf"<{tag}>\n(.*?)\n</{tag}>", text, re.S)
    return found.group(1).strip() if found else None


def install(kai_app, replay):
    """app.py와 AI 모듈의 AI 호출 자리를 대역으로 바꾼다."""
    from src import app_info
    from src.llm import creative_ideas, review

    files = replay["files"]

    def read_biz_cert(image_path):
        if _sha(Path(image_path).read_bytes()) == files["biz_cert"]:
            rec = replay["biz_cert"]
            return {"status": "ok", "fields": dict(rec["fields"]), "missing": [], "warnings": [], **rec["run"]}
        return {"status": "failed", "reason": NO_RECORD, "fields": {}}

    def ask(prompt, schema):
        need = set(schema["required"])
        text = prompt if isinstance(prompt, str) else next(b["text"] for b in prompt if b.get("type") == "text")
        block = None if isinstance(prompt, str) else prompt[0]
        sample_app = f"앱 이름: {replay['app']}\n" in text

        def same_file(kind):
            return bool(block) and _sha(base64.standard_b64decode(block["source"]["data"])) == files[kind]

        def answer(key, fields):
            rec = replay[key]
            return copy.deepcopy({k: rec[k] for k in fields}), dict(rec["run"])

        if need == {"points"} and sample_app:
            return answer("points", ["points"])
        if "image_directions" in need and sample_app:
            return answer("ideas", ["names", "descriptions", "image_directions"])
        if "image_texts" in need:
            rec = replay["creative"]
            if (sample_app and same_file("creative") and _between(text, "캠페인 이름") == rec["cname"]
                    and _between(text, "소개와 참여방법") == rec["cdesc"]):
                return answer("creative", ["image_texts", "prohibited", "opinions"])
            return None, {"reason": NO_RECORD_CREATIVE}
        if "has_seal" in need and same_file("seal_adv") and replay["company"] in text:
            return answer("seal", ["is_application", "has_seal", "company_seen", "note"])
        if "operator_seal" in need and same_file("seal_ops") and replay["company"] in text:
            return answer("final_seal", ["is_application", "advertiser_seal", "operator_seal", "note"])
        return None, {"reason": NO_RECORD}

    def fetch_app_info(url, spec):
        for key, info in replay["store"].items():
            if key in url:
                return {"ok": True, "title": info["title"], "description": info["description"], "url": url}
        return {"ok": False, "reason": NO_STORE, "url": url}

    kai_app.read_biz_cert = read_biz_cert
    kai_app.fetch_app_info = fetch_app_info
    app_info.fetch_app_info = fetch_app_info
    creative_ideas._ask = ask
    review._ask = ask
